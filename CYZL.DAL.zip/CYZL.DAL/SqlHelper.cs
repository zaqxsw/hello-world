﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Reflection;
using System.Data.OleDb;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using System.Text;
using System.Diagnostics;

namespace CKZL.DAL
{
    /// <summary>
    /// 集成SQL数据访问操作
    /// </summary>
    public sealed class SqlHelper
    {
        /// <summary>
        /// 驱动
        /// </summary>
        private string driverClass;
        /// <summary>
        /// 连接字符串
        /// </summary>
        private string connectionString;
        /// <summary>
        /// 连接类型名
        /// </summary>
        private Type conectionType;
        private Type commandType;
        private Type dataAdapterType;
        private Type parameterType;

        private Log log = new Log();

        /// <summary>
        /// 构造函数
        /// </summary>
        public SqlHelper(string connectString)
        {
            try
            {
                this.connectionString = connectString;
                //driverClass = "System.Data.SqlClient";
                driverClass = "MySql.Data.MySqlClient";

                switch (driverClass)
                {
                    case "System.Data.SqlClient":
                        conectionType = typeof(SqlConnection);
                        commandType = typeof(SqlCommand);
                        dataAdapterType = typeof(SqlDataAdapter);
                        parameterType = typeof(SqlParameter);
                        break;

                    case "MySql.Data.MySqlClient":
                        conectionType = typeof(MySqlConnection);
                        commandType = typeof(MySqlCommand);
                        dataAdapterType = typeof(MySqlDataAdapter);
                        parameterType = typeof(MySqlParameter);
                        break;
                    default:
                        break;
                }
            }
            catch (Exception e)
            {
                log.Write(Log.LogType.Error, e.Message);
            }

            if (conectionType == null)
            {
                throw new Exception("数据库驱动类型错误，请仔细检查。");
            }
        }

        internal DbCommand CreateCommand(string sql, DbConnection conn)
        {
            ConstructorInfo ci = commandType.GetConstructor(new Type[] { typeof(string), conectionType });
            DbCommand cmd = (DbCommand)ci.Invoke(new object[] { sql, conn });

            return cmd;
        }

        private DbDataAdapter CreateDataAdapter()
        {
            ConstructorInfo ci = dataAdapterType.GetConstructor(new Type[] { });
            DbDataAdapter ada = (DbDataAdapter)ci.Invoke(new object[] { });

            return ada;
        }

        public DbParameter CreateDbParameter()
        {
            ConstructorInfo ci = parameterType.GetConstructor(new Type[] { });
            DbParameter para = (DbParameter)ci.Invoke(new object[] { });

            return para;
        }

        public DbParameter CreateDbParameter(string name, object value)
        {
            ConstructorInfo ci = parameterType.GetConstructor(new Type[] { });
            DbParameter para = (DbParameter)ci.Invoke(new object[] { });
            para.ParameterName = name;
            para.Value = value;
            para.Direction = ParameterDirection.Input;
            return para;
        }
        public DbParameter CreateDbParameter(string name, object value, ParameterDirection direction)
        {
            ConstructorInfo ci = parameterType.GetConstructor(new Type[] { });
            DbParameter para = (DbParameter)ci.Invoke(new object[] { });
            para.ParameterName = name;
            para.Value = value;
            para.Direction = direction;
            return para;
        }

        public DbParameter CreateDbParameter(string name)
        {
            ConstructorInfo ci = parameterType.GetConstructor(new Type[] { });
            DbParameter para = (DbParameter)ci.Invoke(new object[] { });
            para.ParameterName = name;

            return para;
        }

        /// <summary>
        /// 根据查询语句从数据库检索数据
        /// </summary>
        /// <param name="sql">查询语句,参数格式：(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns>有数据则返回DataTable数据集，否则返回null</returns>
        public DataTable SelectDataTable(string sql, params DbParameter[] parameters)
        {
            DateTime sTime = DateTime.Now;
            DbConnection conn = null;

            try
            {
                conn = GetConnection();
                //sql = PrepareParameter(sql, parameters);
                DbCommand cmd = CreateCommand(sql, conn);
                cmd.Parameters.AddRange(parameters);
                DbDataAdapter sda = CreateDataAdapter();
                sda.SelectCommand = cmd;
                DataTable dt = new DataTable();
                sda.Fill(dt);

                return dt;
            }
            catch (SystemException e)
            {
                log.Write(Log.LogType.Error, "(" + sql + ")：" + e.Message);

                return null;
            }
            finally
            {
                Close(conn);

                double useTime = DateTime.Now.Subtract(sTime).TotalMilliseconds;
                string logStr = "(" + sql + ") 执行时间 " + useTime.ToString("F0") + " 毫秒";
                if (useTime > 5000)
                {
                    log.Write(Log.LogType.Warn, logStr);
                }
#if DEBUG
                log.Write(Log.LogType.Debug, logStr);
#endif
            }
        }

        /// <summary>
        /// 根据查询语句从数据库检索数据
        /// </summary>
        /// <param name="sql">查询语句,参数格式：(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        public DataSet SelectDataSet(string sql, params DbParameter[] parameters)
        {
            DateTime sTime = DateTime.Now;
            DbConnection conn = null;

            try
            {
                conn = GetConnection();
                //sql = PrepareParameter(sql, parameters);
                DbCommand cmd = CreateCommand(sql, conn);
                cmd.Parameters.AddRange(parameters);
                DbDataAdapter sda = CreateDataAdapter();
                sda.SelectCommand = cmd;
                DataSet ds = new DataSet();
                sda.Fill(ds);

                return ds;
            }
            catch (SystemException e)
            {
                log.Write(Log.LogType.Error, "(" + sql + ")：" + e.Message);

                return null;
            }
            finally
            {
                Close(conn);

                double useTime = DateTime.Now.Subtract(sTime).TotalMilliseconds;
                string logStr = "(" + sql + ") 执行时间 " + useTime.ToString("F0") + " 毫秒";
                if (useTime > 5000)
                {
                    log.Write(Log.LogType.Warn, logStr);
                }
#if DEBUG
                log.Write(Log.LogType.Debug, logStr);
#endif
            }
        }

        /// <summary>
        /// 查询表对象
        /// </summary>
        /// <param name="sql">查询语句,参数格式：(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns>表对象,只绑定选择的字段值</returns>
        public T[] Select<T>(string sql, params DbParameter[] parameters)
        {
            DateTime sTime = DateTime.Now;
            Type type = typeof(T);
            if (string.IsNullOrEmpty(sql))
            {
                return null;
            }
            else
            {
                List<T> t = new List<T>();
                DbConnection conn = null;
                try
                {
                    conn = GetConnection();
                    //sql = PrepareParameter(sql, parameters);
                    DbCommand cmd = CreateCommand(sql, conn);
                    cmd.Parameters.AddRange(parameters);
                    DbDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                    cmd.Parameters.Clear();

                    if (type != null)
                    {
                        int fc = rdr.FieldCount;
                        DataRowCollection drs = rdr.GetSchemaTable().Rows;
                        List<string> cns = new List<string>();
                        foreach (DataRow dr in drs)
                        {
                            cns.Add(dr.ItemArray[0].ToString().ToLower());
                        }

                        FieldInfo[] fis;
                        bool isView = type.BaseType.FullName.Contains("DAL.Base.View");
                        if (isView)
                        {
                            fis = type.GetFields();
                        }
                        else
                        {
                            fis = type.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                        }

                        while (rdr.Read())
                        {
                            ConstructorInfo constructor = type.GetConstructor(new Type[0]);
                            object obj = constructor.Invoke(new Object[0]);
                            foreach (FieldInfo fi in fis)
                            {
                                string fn = fi.Name.ToLower();
                                if (fn.StartsWith("_"))
                                {
                                    fn = fn.Substring(1);
                                }
                                if (cns.Contains(fn))
                                {
                                    object v = rdr[fn];
                                    if (v.GetType() != typeof(DBNull))
                                    {
                                        fi.SetValue(obj, Convert.ChangeType(v, fi.FieldType));
                                    }
                                }
                            }

                            t.Add((T)obj);
                        }
                        rdr.Close();
                    }

                    return t.ToArray();
                }
                catch (Exception e)
                {
                    log.Write(Log.LogType.Error, "(" + sql + ")" + e.Message);
                    return null;
                }
                finally
                {
                    Close(conn);

                    double useTime = DateTime.Now.Subtract(sTime).TotalMilliseconds;
                    string logStr = "(" + sql + ") 执行时间 " + useTime.ToString("F0") + " 毫秒";
                    if (useTime > 5000)
                    {
                        log.Write(Log.LogType.Warn, logStr);
                    }
#if DEBUG
                    log.Write(Log.LogType.Debug, logStr);
#endif
                }
            }
        }

        /// <summary>
        /// 添加、更新、删除
        /// </summary>
        /// <param name="sql">查询语句,参数格式：(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns>受影响的行数</returns>
        public int ExecuteNonQuery(string sql, params DbParameter[] parameters)
        {
            DateTime sTime = DateTime.Now;
            if (sql.Trim().Length == 0)
            {
                return 0;
            }

            DbConnection conn = null;
            DbTransaction trans = null;

            try
            {
                conn = GetConnection();
                //sql = PrepareParameter(sql, parameters);
                trans = conn.BeginTransaction();
                DbCommand cmd = CreateCommand(sql, conn);
                cmd.Transaction = trans;
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddRange(parameters);
                int result = cmd.ExecuteNonQuery();
                trans.Commit();

                return result;
            }
            catch (SystemException e)
            {
                if (trans != null)
                {
                    trans.Rollback();
                }

                log.Write(Log.LogType.Error, "(" + sql + ")：" + e.Message);

                return -1;
            }
            finally
            {
                Close(conn);

                double useTime = DateTime.Now.Subtract(sTime).TotalMilliseconds;
                string logStr = "(" + sql + ") 执行时间 " + useTime.ToString("F0") + " 毫秒";
                if (useTime > 5000)
                {
                    log.Write(Log.LogType.Warn, logStr);
                }
#if DEBUG
                log.Write(Log.LogType.Debug, logStr);
#endif
            }
        }

        /// <summary>
        /// 执行查询，并返回查询多返回的结果集中第一行的第一列。忽略其他列或行。
        /// </summary>
        /// <param name="sql">查询语句,参数格式：(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns>结果集中第一行的第一列</returns>
        public object ExecuteScalar(string sql, params DbParameter[] parameters)
        {
            DateTime sTime = DateTime.Now;
            DbConnection conn = null;

            try
            {
                conn = GetConnection();
                //sql = PrepareParameter(sql, parameters);
                DbCommand cmd = CreateCommand(sql, conn);
                cmd.Parameters.AddRange(parameters);
                return cmd.ExecuteScalar();
            }
            catch
            {
                return null;
            }
            finally
            {
                Close(conn);

                double useTime = DateTime.Now.Subtract(sTime).TotalMilliseconds;
                string logStr = "(" + sql + ") 执行时间 " + useTime.ToString("F0") + " 毫秒";
                if (useTime > 5000)
                {
                    log.Write(Log.LogType.Warn, logStr);
                }
#if DEBUG
                log.Write(Log.LogType.Debug, logStr);
#endif
            }
        }

        /// <summary>
        /// 执行存储过程
        /// </summary>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        public int ExecuteStoredProcNonQuery(string spName, params DbParameter[] parameters)
        {
            DateTime sTime = DateTime.Now;
            DbConnection conn = null;
            DbTransaction trans = null;

            try
            {
                conn = GetConnection();
                trans = conn.BeginTransaction();
                DbCommand cmd = CreateCommand(spName, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trans;
                cmd.Parameters.AddRange(parameters);

                int result = cmd.ExecuteNonQuery();
                trans.Commit();

                return result;
            }
            catch (DbException e)
            {
                if (trans != null)
                {
                    trans.Rollback();
                }
                log.Write(Log.LogType.Error, "(" + spName + ")：" + e.Message);

                return -1;
            }
            finally
            {
                Close(conn);

                double useTime = DateTime.Now.Subtract(sTime).TotalMilliseconds;
                string logStr = "(" + spName + ") 执行时间 " + useTime.ToString("F0") + " 毫秒";
                if (useTime > 5000)
                {
                    log.Write(Log.LogType.Warn, logStr);
                }
#if DEBUG
                log.Write(Log.LogType.Debug, logStr);
#endif
            }
        }

        public DataSet ExecuteStoredProcWithDataSet(string spName, ref DbParameter[] parameters)
        {
            DateTime sTime = DateTime.Now;
            DbConnection conn = null;
            DbTransaction trans = null;

            try
            {
                conn = GetConnection();
                trans = conn.BeginTransaction();
                DbDataAdapter da = CreateDataAdapter();
                DataSet ds = new DataSet();
                DbCommand cmd = CreateCommand(spName, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trans;
                cmd.Parameters.AddRange(parameters);

                da.SelectCommand = cmd;
                da.Fill(ds);
                trans.Commit();

                return ds;
            }
            catch (DbException e)
            {
                if (trans != null)
                {
                    trans.Rollback();
                }
                log.Write(Log.LogType.Error, "(" + spName + ")：" + e.Message);

                return null;
            }
            finally
            {
                Close(conn);

                double useTime = DateTime.Now.Subtract(sTime).TotalMilliseconds;
                string logStr = "(" + spName + ") 执行时间 " + useTime.ToString("F0") + " 毫秒";
                if (useTime > 5000)
                {
                    log.Write(Log.LogType.Warn, logStr);
                }
#if DEBUG
                log.Write(Log.LogType.Debug, logStr);
#endif
            }
        }

        internal void Close(DbConnection conn)
        {
            if (conn != null)
            {
                conn.Close();
            }
        }

        internal DbConnection GetConnection()
        {
            DbConnection conn = null;

            try
            {
                ConstructorInfo ci = conectionType.GetConstructor(new Type[] { typeof(string) });
                conn = (DbConnection)ci.Invoke(new object[] { connectionString });
                conn.Open();
            }
            catch (Exception e)
            {
                log.Write(Log.LogType.Error, e.Message);
                return null;
            }

            return conn;
        }

        //internal  string PrepareParameter(string sql, object[] parameters)
        //{
        //    return PrepareParameter(sql, parameters, 0);
        //}

        //internal  string PrepareParameter(string sql, object[] parameters, int paraStartIndex)
        //{
        //    if (sql.Contains("?"))
        //    {
        //        string[] ss = sql.Split('?');
        //        if (ss.Length - 1 == parameters.Length)
        //        {
        //            StringBuilder sb = new StringBuilder();
        //            for (int i = 0; i < ss.Length - 1; i++)
        //            {
        //                sb.Append(ss[i]).Append("@p").Append((i + paraStartIndex).ToString());
        //                parameters[i] = Sql.CreateDbParameter("@p" + (i + paraStartIndex).ToString(), parameters[i]);
        //            }
        //            sb.Append(ss[ss.Length - 1]);
        //            sql = sb.ToString();
        //        }
        //        else
        //        {
        //            throw new Exception("Sql.PrepareParameter sql(" + sql + ") 参数数量不对");
        //        }
        //    }

        //    return sql;
        //}
    }
}
