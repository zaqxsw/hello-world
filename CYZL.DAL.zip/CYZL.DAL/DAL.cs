﻿/* **********************************************************************
本DAL由DALBuilder工具生成，请匆手工修改。
生成时间：2023/6/17 16:08:16
*************************************************************************/
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace CKZL.DAL
{
/// <summary>
/// 数据表：TClientAuthorization
/// </summary>
public class TClientAuthorization : Table<TClientAuthorization>
{
	private long? _RecordId;
	private DateTime? _CreateTime;
	private string _CreatedByUserId;
	private string _AuthorizeTo;
	private DateTime? _ExpireDate;
	private string _Description;
	private string _AuthCode;

	public TClientAuthorization()
	{
		tableName = "TClientAuthorization";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateTime
	{
		get
		{
			return this._CreateTime;
		}
		set
		{
			this._CreateTime = value;
			SetEditField("CreateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string CreatedByUserId
	{
		get
		{
			return this._CreatedByUserId;
		}
		set
		{
			this._CreatedByUserId = value;
			SetEditField("CreatedByUserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string AuthorizeTo
	{
		get
		{
			return this._AuthorizeTo;
		}
		set
		{
			this._AuthorizeTo = value;
			SetEditField("AuthorizeTo", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? ExpireDate
	{
		get
		{
			return this._ExpireDate;
		}
		set
		{
			this._ExpireDate = value;
			SetEditField("ExpireDate", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Description
	{
		get
		{
			return this._Description;
		}
		set
		{
			this._Description = value;
			SetEditField("Description", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(1000)]、  [可以为NULL]、
	/// </summary>
	public string AuthCode
	{
		get
		{
			return this._AuthCode;
		}
		set
		{
			this._AuthCode = value;
			SetEditField("AuthCode", value);
		}
	}

}

/// <summary>
/// 数据表：TClientHelp
/// </summary>
public class TClientHelp : Table<TClientHelp>
{
	private string _HelpId;
	private string _Name;
	private string _ApplyTo;
	private int? _DisplayOrder;

	public TClientHelp()
	{
		tableName = "TClientHelp";
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [不能为NULL]、
	/// </summary>
	public string HelpId
	{
		get
		{
			return this._HelpId;
		}
		set
		{
			this._HelpId = value;
			SetEditField("HelpId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [可以为NULL]、
	/// </summary>
	public string Name
	{
		get
		{
			return this._Name;
		}
		set
		{
			this._Name = value;
			SetEditField("Name", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [可以为NULL]、
	/// </summary>
	public string ApplyTo
	{
		get
		{
			return this._ApplyTo;
		}
		set
		{
			this._ApplyTo = value;
			SetEditField("ApplyTo", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? DisplayOrder
	{
		get
		{
			return this._DisplayOrder;
		}
		set
		{
			this._DisplayOrder = value;
			SetEditField("DisplayOrder", value);
		}
	}

}

/// <summary>
/// 数据表：TClientHelpContent
/// </summary>
public class TClientHelpContent : Table<TClientHelpContent>
{
	private string _HelpId;
	private string _DocumentType;
	private DateTime? _LastUpdatedTime;
	private string _HelpContent;

	public TClientHelpContent()
	{
		tableName = "TClientHelpContent";
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [可以为NULL]、
	/// </summary>
	public string HelpId
	{
		get
		{
			return this._HelpId;
		}
		set
		{
			this._HelpId = value;
			SetEditField("HelpId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [可以为NULL]、
	/// </summary>
	public string DocumentType
	{
		get
		{
			return this._DocumentType;
		}
		set
		{
			this._DocumentType = value;
			SetEditField("DocumentType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastUpdatedTime
	{
		get
		{
			return this._LastUpdatedTime;
		}
		set
		{
			this._LastUpdatedTime = value;
			SetEditField("LastUpdatedTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string HelpContent
	{
		get
		{
			return this._HelpContent;
		}
		set
		{
			this._HelpContent = value;
			SetEditField("HelpContent", value);
		}
	}

}

/// <summary>
/// 数据表：TCustomerService
/// </summary>
public class TCustomerService : Table<TCustomerService>
{
	private int? _Id;
	private long? _QQ;
	private string _Name;

	public TCustomerService()
	{
		tableName = "TCustomerService";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public int? Id
	{
		get
		{
			return this._Id;
		}
		set
		{
			this._Id = value;
			SetEditField("Id", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? QQ
	{
		get
		{
			return this._QQ;
		}
		set
		{
			this._QQ = value;
			SetEditField("QQ", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string Name
	{
		get
		{
			return this._Name;
		}
		set
		{
			this._Name = value;
			SetEditField("Name", value);
		}
	}

}

/// <summary>
/// 数据表：TDocument
/// </summary>
public class TDocument : Table<TDocument>
{
	private long? _DocumentId;
	private string _DocumentType;
	private long? _UserId;
	private string _Title;
	private string _Description;
	private DateTime? _CreateTime;
	private DateTime? _LastChangeTime;
	private long? _LastChangeBySessionId;
	private string _StatusCode;
	private int? _Version;
	private int? _Progress;
	private DateTime? _ProgressUpdateTime;
	private bool? _InputFenxiOnly;

	public TDocument()
	{
		tableName = "TDocument";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string DocumentType
	{
		get
		{
			return this._DocumentType;
		}
		set
		{
			this._DocumentType = value;
			SetEditField("DocumentType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? UserId
	{
		get
		{
			return this._UserId;
		}
		set
		{
			this._UserId = value;
			SetEditField("UserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Title
	{
		get
		{
			return this._Title;
		}
		set
		{
			this._Title = value;
			SetEditField("Title", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Description
	{
		get
		{
			return this._Description;
		}
		set
		{
			this._Description = value;
			SetEditField("Description", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateTime
	{
		get
		{
			return this._CreateTime;
		}
		set
		{
			this._CreateTime = value;
			SetEditField("CreateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastChangeTime
	{
		get
		{
			return this._LastChangeTime;
		}
		set
		{
			this._LastChangeTime = value;
			SetEditField("LastChangeTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? LastChangeBySessionId
	{
		get
		{
			return this._LastChangeBySessionId;
		}
		set
		{
			this._LastChangeBySessionId = value;
			SetEditField("LastChangeBySessionId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string StatusCode
	{
		get
		{
			return this._StatusCode;
		}
		set
		{
			this._StatusCode = value;
			SetEditField("StatusCode", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? Version
	{
		get
		{
			return this._Version;
		}
		set
		{
			this._Version = value;
			SetEditField("Version", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? Progress
	{
		get
		{
			return this._Progress;
		}
		set
		{
			this._Progress = value;
			SetEditField("Progress", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? ProgressUpdateTime
	{
		get
		{
			return this._ProgressUpdateTime;
		}
		set
		{
			this._ProgressUpdateTime = value;
			SetEditField("ProgressUpdateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public bool? InputFenxiOnly
	{
		get
		{
			return this._InputFenxiOnly;
		}
		set
		{
			this._InputFenxiOnly = value;
			SetEditField("InputFenxiOnly", value);
		}
	}

}

/// <summary>
/// 数据表：TDocumentImage
/// </summary>
public class TDocumentImage : Table<TDocumentImage>
{
	private long? _ImageId;
	private string _ImageGuid;
	private string _Type;
	private string _Number;
	private long? _DocumentId;
	private int? _UserId;
	private string _LocationName;
	private string _Subfolder;
	private string _FileName;
	private DateTime? _UploadTime;
	private int? _DisplayOrder;
	private string _Labels;
	private string _Description;
	private DateTime? _LastUpdatedTime;

	public TDocumentImage()
	{
		tableName = "TDocumentImage";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? ImageId
	{
		get
		{
			return this._ImageId;
		}
		set
		{
			this._ImageId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(40)]、  [可以为NULL]、
	/// </summary>
	public string ImageGuid
	{
		get
		{
			return this._ImageGuid;
		}
		set
		{
			this._ImageGuid = value;
			SetEditField("ImageGuid", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string Type
	{
		get
		{
			return this._Type;
		}
		set
		{
			this._Type = value;
			SetEditField("Type", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [可以为NULL]、
	/// </summary>
	public string Number
	{
		get
		{
			return this._Number;
		}
		set
		{
			this._Number = value;
			SetEditField("Number", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public int? UserId
	{
		get
		{
			return this._UserId;
		}
		set
		{
			this._UserId = value;
			SetEditField("UserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(30)]、  [可以为NULL]、
	/// </summary>
	public string LocationName
	{
		get
		{
			return this._LocationName;
		}
		set
		{
			this._LocationName = value;
			SetEditField("LocationName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(250)]、  [可以为NULL]、
	/// </summary>
	public string Subfolder
	{
		get
		{
			return this._Subfolder;
		}
		set
		{
			this._Subfolder = value;
			SetEditField("Subfolder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [不能为NULL]、
	/// </summary>
	public string FileName
	{
		get
		{
			return this._FileName;
		}
		set
		{
			this._FileName = value;
			SetEditField("FileName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// 默认值：(getdate())
	/// </summary>
	public DateTime? UploadTime
	{
		get
		{
			return this._UploadTime;
		}
		set
		{
			this._UploadTime = value;
			SetEditField("UploadTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? DisplayOrder
	{
		get
		{
			return this._DisplayOrder;
		}
		set
		{
			this._DisplayOrder = value;
			SetEditField("DisplayOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Labels
	{
		get
		{
			return this._Labels;
		}
		set
		{
			this._Labels = value;
			SetEditField("Labels", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Description
	{
		get
		{
			return this._Description;
		}
		set
		{
			this._Description = value;
			SetEditField("Description", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastUpdatedTime
	{
		get
		{
			return this._LastUpdatedTime;
		}
		set
		{
			this._LastUpdatedTime = value;
			SetEditField("LastUpdatedTime", value);
		}
	}

}

/// <summary>
/// 数据表：TDocumentImageLabel
/// </summary>
public class TDocumentImageLabel : Table<TDocumentImageLabel>
{
	private long? _ImageLabelId;
	private long? _DocumentId;
	private long? _ImageId;
	private string _LabelName;
	private string _LabelDescription;
	private int? _DisplayOrder;

	public TDocumentImageLabel()
	{
		tableName = "TDocumentImageLabel";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? ImageLabelId
	{
		get
		{
			return this._ImageLabelId;
		}
		set
		{
			this._ImageLabelId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? ImageId
	{
		get
		{
			return this._ImageId;
		}
		set
		{
			this._ImageId = value;
			SetEditField("ImageId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [可以为NULL]、
	/// </summary>
	public string LabelName
	{
		get
		{
			return this._LabelName;
		}
		set
		{
			this._LabelName = value;
			SetEditField("LabelName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(250)]、  [可以为NULL]、
	/// </summary>
	public string LabelDescription
	{
		get
		{
			return this._LabelDescription;
		}
		set
		{
			this._LabelDescription = value;
			SetEditField("LabelDescription", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? DisplayOrder
	{
		get
		{
			return this._DisplayOrder;
		}
		set
		{
			this._DisplayOrder = value;
			SetEditField("DisplayOrder", value);
		}
	}

}

/// <summary>
/// 数据表：TDocumentImport
/// </summary>
public class TDocumentImport : Table<TDocumentImport>
{
	private long? _RecordId;
	private int? _UserId;
	private DateTime? _UploadTime;
	private string _UploadType;
	private string _RawFileName;
	private string _FileExt;
	private string _StorePath;
	private int? _Status;
	private DateTime? _ProcessTime;
	private int? _ImportAsDocumentId;
	private string _ProcessErrorMessage;

	public TDocumentImport()
	{
		tableName = "TDocumentImport";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? UserId
	{
		get
		{
			return this._UserId;
		}
		set
		{
			this._UserId = value;
			SetEditField("UserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? UploadTime
	{
		get
		{
			return this._UploadTime;
		}
		set
		{
			this._UploadTime = value;
			SetEditField("UploadTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [可以为NULL]、
	/// </summary>
	public string UploadType
	{
		get
		{
			return this._UploadType;
		}
		set
		{
			this._UploadType = value;
			SetEditField("UploadType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string RawFileName
	{
		get
		{
			return this._RawFileName;
		}
		set
		{
			this._RawFileName = value;
			SetEditField("RawFileName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [可以为NULL]、
	/// </summary>
	public string FileExt
	{
		get
		{
			return this._FileExt;
		}
		set
		{
			this._FileExt = value;
			SetEditField("FileExt", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(250)]、  [可以为NULL]、
	/// </summary>
	public string StorePath
	{
		get
		{
			return this._StorePath;
		}
		set
		{
			this._StorePath = value;
			SetEditField("StorePath", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? Status
	{
		get
		{
			return this._Status;
		}
		set
		{
			this._Status = value;
			SetEditField("Status", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? ProcessTime
	{
		get
		{
			return this._ProcessTime;
		}
		set
		{
			this._ProcessTime = value;
			SetEditField("ProcessTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? ImportAsDocumentId
	{
		get
		{
			return this._ImportAsDocumentId;
		}
		set
		{
			this._ImportAsDocumentId = value;
			SetEditField("ImportAsDocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ProcessErrorMessage
	{
		get
		{
			return this._ProcessErrorMessage;
		}
		set
		{
			this._ProcessErrorMessage = value;
			SetEditField("ProcessErrorMessage", value);
		}
	}

}

/// <summary>
/// 数据表：TDocumentImportContent
/// </summary>
public class TDocumentImportContent : Table<TDocumentImportContent>
{
	private long? _DocumentImportId;
	private string _Title;
	private string _TechArea;
	private string _TechBackground;
	private string _FMContent;
	private string _AttachedImages;
	private string _Implementation;

	public TDocumentImportContent()
	{
		tableName = "TDocumentImportContent";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentImportId
	{
		get
		{
			return this._DocumentImportId;
		}
		set
		{
			this._DocumentImportId = value;
			SetEditField("DocumentImportId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Title
	{
		get
		{
			return this._Title;
		}
		set
		{
			this._Title = value;
			SetEditField("Title", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string TechArea
	{
		get
		{
			return this._TechArea;
		}
		set
		{
			this._TechArea = value;
			SetEditField("TechArea", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string TechBackground
	{
		get
		{
			return this._TechBackground;
		}
		set
		{
			this._TechBackground = value;
			SetEditField("TechBackground", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string FMContent
	{
		get
		{
			return this._FMContent;
		}
		set
		{
			this._FMContent = value;
			SetEditField("FMContent", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string AttachedImages
	{
		get
		{
			return this._AttachedImages;
		}
		set
		{
			this._AttachedImages = value;
			SetEditField("AttachedImages", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string Implementation
	{
		get
		{
			return this._Implementation;
		}
		set
		{
			this._Implementation = value;
			SetEditField("Implementation", value);
		}
	}

}

/// <summary>
/// 数据表：TDocumentImportImage
/// </summary>
public class TDocumentImportImage : Table<TDocumentImportImage>
{
	private string _ImageId;
	private string _Type;
	private string _Number;
	private long? _DocumentImportId;
	private int? _UserId;
	private string _StoreFilePath;
	private int? _DisplayOrder;
	private string _Description;

	public TDocumentImportImage()
	{
		tableName = "TDocumentImportImage";
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [不能为NULL]、
	/// </summary>
	public string ImageId
	{
		get
		{
			return this._ImageId;
		}
		set
		{
			this._ImageId = value;
			SetEditField("ImageId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string Type
	{
		get
		{
			return this._Type;
		}
		set
		{
			this._Type = value;
			SetEditField("Type", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [可以为NULL]、
	/// </summary>
	public string Number
	{
		get
		{
			return this._Number;
		}
		set
		{
			this._Number = value;
			SetEditField("Number", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentImportId
	{
		get
		{
			return this._DocumentImportId;
		}
		set
		{
			this._DocumentImportId = value;
			SetEditField("DocumentImportId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public int? UserId
	{
		get
		{
			return this._UserId;
		}
		set
		{
			this._UserId = value;
			SetEditField("UserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(250)]、  [不能为NULL]、
	/// </summary>
	public string StoreFilePath
	{
		get
		{
			return this._StoreFilePath;
		}
		set
		{
			this._StoreFilePath = value;
			SetEditField("StoreFilePath", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? DisplayOrder
	{
		get
		{
			return this._DisplayOrder;
		}
		set
		{
			this._DisplayOrder = value;
			SetEditField("DisplayOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Description
	{
		get
		{
			return this._Description;
		}
		set
		{
			this._Description = value;
			SetEditField("Description", value);
		}
	}

}

/// <summary>
/// 数据表：TDocumentMindMap
/// </summary>
public class TDocumentMindMap : Table<TDocumentMindMap>
{
	private long? _DocumentId;
	private string _XMLContent;
	private DateTime? _LastUpdatedTime;
	private long? _LastUpdatedUserId;

	public TDocumentMindMap()
	{
		tableName = "TDocumentMindMap";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string XMLContent
	{
		get
		{
			return this._XMLContent;
		}
		set
		{
			this._XMLContent = value;
			SetEditField("XMLContent", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastUpdatedTime
	{
		get
		{
			return this._LastUpdatedTime;
		}
		set
		{
			this._LastUpdatedTime = value;
			SetEditField("LastUpdatedTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? LastUpdatedUserId
	{
		get
		{
			return this._LastUpdatedUserId;
		}
		set
		{
			this._LastUpdatedUserId = value;
			SetEditField("LastUpdatedUserId", value);
		}
	}

}

/// <summary>
/// 数据表：TDocumentSession
/// </summary>
public class TDocumentSession : Table<TDocumentSession>
{
	private long? _SessionId;
	private long? _DocumentId;
	private long? _UserId;
	private string _UserName;
	private DateTime? _OpenTime;
	private DateTime? _LastHeartBeatTime;
	private DateTime? _LastEditTime;

	public TDocumentSession()
	{
		tableName = "TDocumentSession";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? SessionId
	{
		get
		{
			return this._SessionId;
		}
		set
		{
			this._SessionId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? UserId
	{
		get
		{
			return this._UserId;
		}
		set
		{
			this._UserId = value;
			SetEditField("UserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string UserName
	{
		get
		{
			return this._UserName;
		}
		set
		{
			this._UserName = value;
			SetEditField("UserName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? OpenTime
	{
		get
		{
			return this._OpenTime;
		}
		set
		{
			this._OpenTime = value;
			SetEditField("OpenTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastHeartBeatTime
	{
		get
		{
			return this._LastHeartBeatTime;
		}
		set
		{
			this._LastHeartBeatTime = value;
			SetEditField("LastHeartBeatTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastEditTime
	{
		get
		{
			return this._LastEditTime;
		}
		set
		{
			this._LastEditTime = value;
			SetEditField("LastEditTime", value);
		}
	}

}

/// <summary>
/// 数据表：TDocumentStatus
/// </summary>
public class TDocumentStatus : Table<TDocumentStatus>
{
	private string _StatusCode;
	private string _StatusName;

	public TDocumentStatus()
	{
		tableName = "TDocumentStatus";
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [不能为NULL]、
	/// </summary>
	public string StatusCode
	{
		get
		{
			return this._StatusCode;
		}
		set
		{
			this._StatusCode = value;
			SetEditField("StatusCode", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string StatusName
	{
		get
		{
			return this._StatusName;
		}
		set
		{
			this._StatusName = value;
			SetEditField("StatusName", value);
		}
	}

}

/// <summary>
/// 数据表：TDocumentType
/// </summary>
public class TDocumentType : Table<TDocumentType>
{
	private string _DocumentType;
	private string _DocumentTypeName;
	private string _TemplateWordFileName;

	public TDocumentType()
	{
		tableName = "TDocumentType";
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [不能为NULL]、
	/// </summary>
	public string DocumentType
	{
		get
		{
			return this._DocumentType;
		}
		set
		{
			this._DocumentType = value;
			SetEditField("DocumentType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string DocumentTypeName
	{
		get
		{
			return this._DocumentTypeName;
		}
		set
		{
			this._DocumentTypeName = value;
			SetEditField("DocumentTypeName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [可以为NULL]、
	/// </summary>
	public string TemplateWordFileName
	{
		get
		{
			return this._TemplateWordFileName;
		}
		set
		{
			this._TemplateWordFileName = value;
			SetEditField("TemplateWordFileName", value);
		}
	}

}

/// <summary>
/// 数据表：TExportWordRequest
/// </summary>
public class TExportWordRequest : Table<TExportWordRequest>
{
	private long? _RequestId;
	private long? _DocumentId;
	private long? _RequestUserId;
	private DateTime? _RequestTime;
	private DateTime? _ProcessTime;
	private DateTime? _CompleteTime;
	private int? _Status;
	private string _FilePath;
	private string _ErrorMessage;

	public TExportWordRequest()
	{
		tableName = "TExportWordRequest";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? RequestId
	{
		get
		{
			return this._RequestId;
		}
		set
		{
			this._RequestId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? RequestUserId
	{
		get
		{
			return this._RequestUserId;
		}
		set
		{
			this._RequestUserId = value;
			SetEditField("RequestUserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? RequestTime
	{
		get
		{
			return this._RequestTime;
		}
		set
		{
			this._RequestTime = value;
			SetEditField("RequestTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? ProcessTime
	{
		get
		{
			return this._ProcessTime;
		}
		set
		{
			this._ProcessTime = value;
			SetEditField("ProcessTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CompleteTime
	{
		get
		{
			return this._CompleteTime;
		}
		set
		{
			this._CompleteTime = value;
			SetEditField("CompleteTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? Status
	{
		get
		{
			return this._Status;
		}
		set
		{
			this._Status = value;
			SetEditField("Status", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(250)]、  [可以为NULL]、
	/// </summary>
	public string FilePath
	{
		get
		{
			return this._FilePath;
		}
		set
		{
			this._FilePath = value;
			SetEditField("FilePath", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ErrorMessage
	{
		get
		{
			return this._ErrorMessage;
		}
		set
		{
			this._ErrorMessage = value;
			SetEditField("ErrorMessage", value);
		}
	}

}

/// <summary>
/// 数据表：TFeeConfig
/// </summary>
public class TFeeConfig : Table<TFeeConfig>
{
	private int? _ConfigId;
	private string _Name;
	private string _Description;
	private decimal? _Fee;

	public TFeeConfig()
	{
		tableName = "TFeeConfig";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public int? ConfigId
	{
		get
		{
			return this._ConfigId;
		}
		set
		{
			this._ConfigId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [不能为NULL]、
	/// </summary>
	public string Name
	{
		get
		{
			return this._Name;
		}
		set
		{
			this._Name = value;
			SetEditField("Name", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(1000)]、  [可以为NULL]、
	/// </summary>
	public string Description
	{
		get
		{
			return this._Description;
		}
		set
		{
			this._Description = value;
			SetEditField("Description", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public decimal? Fee
	{
		get
		{
			return this._Fee;
		}
		set
		{
			this._Fee = value;
			SetEditField("Fee", value);
		}
	}

}

/// <summary>
/// 数据表：TFeedback
/// </summary>
public class TFeedback : Table<TFeedback>
{
	private int? _RecordId;
	private string _Category;
	private DateTime? _CreateTime;
	private string _Contact;
	private string _Text;
	private string _HtmlContent;

	public TFeedback()
	{
		tableName = "TFeedback";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public int? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string Category
	{
		get
		{
			return this._Category;
		}
		set
		{
			this._Category = value;
			SetEditField("Category", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateTime
	{
		get
		{
			return this._CreateTime;
		}
		set
		{
			this._CreateTime = value;
			SetEditField("CreateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [可以为NULL]、
	/// </summary>
	public string Contact
	{
		get
		{
			return this._Contact;
		}
		set
		{
			this._Contact = value;
			SetEditField("Contact", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Text
	{
		get
		{
			return this._Text;
		}
		set
		{
			this._Text = value;
			SetEditField("Text", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string HtmlContent
	{
		get
		{
			return this._HtmlContent;
		}
		set
		{
			this._HtmlContent = value;
			SetEditField("HtmlContent", value);
		}
	}

}

/// <summary>
/// 数据表：TFeedbackImage
/// </summary>
public class TFeedbackImage : Table<TFeedbackImage>
{
	private long? _ImageId;
	private string _Category;
	private string _Directory;
	private string _FileName;
	private DateTime? _UploadTime;

	public TFeedbackImage()
	{
		tableName = "TFeedbackImage";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? ImageId
	{
		get
		{
			return this._ImageId;
		}
		set
		{
			this._ImageId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string Category
	{
		get
		{
			return this._Category;
		}
		set
		{
			this._Category = value;
			SetEditField("Category", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(250)]、  [不能为NULL]、
	/// </summary>
	public string Directory
	{
		get
		{
			return this._Directory;
		}
		set
		{
			this._Directory = value;
			SetEditField("Directory", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [不能为NULL]、
	/// </summary>
	public string FileName
	{
		get
		{
			return this._FileName;
		}
		set
		{
			this._FileName = value;
			SetEditField("FileName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// 默认值：(getdate())
	/// </summary>
	public DateTime? UploadTime
	{
		get
		{
			return this._UploadTime;
		}
		set
		{
			this._UploadTime = value;
			SetEditField("UploadTime", value);
		}
	}

}

/// <summary>
/// 数据表：TInputJishuWenti
/// </summary>
public class TInputJishuWenti : Table<TInputJishuWenti>
{
	private long? _RecordId;
	private long? _ParentRecordId;
	private long? _DocumentId;
	private long? _JishuZhutiId;
	private string _FanganType;
	private string _Title;
	private string _JSFA;
	private string _JSXG;
	private double? _PosX;
	private double? _PosY;
	private DateTime? _LastUpdateTime;

	public TInputJishuWenti()
	{
		tableName = "TInputJishuWenti";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? ParentRecordId
	{
		get
		{
			return this._ParentRecordId;
		}
		set
		{
			this._ParentRecordId = value;
			SetEditField("ParentRecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? JishuZhutiId
	{
		get
		{
			return this._JishuZhutiId;
		}
		set
		{
			this._JishuZhutiId = value;
			SetEditField("JishuZhutiId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string FanganType
	{
		get
		{
			return this._FanganType;
		}
		set
		{
			this._FanganType = value;
			SetEditField("FanganType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Title
	{
		get
		{
			return this._Title;
		}
		set
		{
			this._Title = value;
			SetEditField("Title", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string JSFA
	{
		get
		{
			return this._JSFA;
		}
		set
		{
			this._JSFA = value;
			SetEditField("JSFA", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string JSXG
	{
		get
		{
			return this._JSXG;
		}
		set
		{
			this._JSXG = value;
			SetEditField("JSXG", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public double? PosX
	{
		get
		{
			return this._PosX;
		}
		set
		{
			this._PosX = value;
			SetEditField("PosX", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public double? PosY
	{
		get
		{
			return this._PosY;
		}
		set
		{
			this._PosY = value;
			SetEditField("PosY", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastUpdateTime
	{
		get
		{
			return this._LastUpdateTime;
		}
		set
		{
			this._LastUpdateTime = value;
			SetEditField("LastUpdateTime", value);
		}
	}

}

/// <summary>
/// 数据表：TInputJishuZhuti
/// </summary>
public class TInputJishuZhuti : Table<TInputJishuZhuti>
{
	private long? _Id;
	private long? _DocumentId;
	private string _Title;
	private Int16? _Type;
	private double? _PosX;
	private double? _PosY;
	private DateTime? _LastUpdateTime;

	public TInputJishuZhuti()
	{
		tableName = "TInputJishuZhuti";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? Id
	{
		get
		{
			return this._Id;
		}
		set
		{
			this._Id = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Title
	{
		get
		{
			return this._Title;
		}
		set
		{
			this._Title = value;
			SetEditField("Title", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public Int16? Type
	{
		get
		{
			return this._Type;
		}
		set
		{
			this._Type = value;
			SetEditField("Type", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public double? PosX
	{
		get
		{
			return this._PosX;
		}
		set
		{
			this._PosX = value;
			SetEditField("PosX", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public double? PosY
	{
		get
		{
			return this._PosY;
		}
		set
		{
			this._PosY = value;
			SetEditField("PosY", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastUpdateTime
	{
		get
		{
			return this._LastUpdateTime;
		}
		set
		{
			this._LastUpdateTime = value;
			SetEditField("LastUpdateTime", value);
		}
	}

}

/// <summary>
/// 数据表：TInputManualAndHelp
/// </summary>
public class TInputManualAndHelp : Table<TInputManualAndHelp>
{
	private long? _RecordId;
	private string _DocumentType;
	private string _InputType;
	private string _ManualHTML;
	private string _ManualText;
	private string _HelpHTML;
	private string _HelpText;

	public TInputManualAndHelp()
	{
		tableName = "TInputManualAndHelp";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [不能为NULL]、
	/// </summary>
	public string DocumentType
	{
		get
		{
			return this._DocumentType;
		}
		set
		{
			this._DocumentType = value;
			SetEditField("DocumentType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [不能为NULL]、
	/// </summary>
	public string InputType
	{
		get
		{
			return this._InputType;
		}
		set
		{
			this._InputType = value;
			SetEditField("InputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string ManualHTML
	{
		get
		{
			return this._ManualHTML;
		}
		set
		{
			this._ManualHTML = value;
			SetEditField("ManualHTML", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string ManualText
	{
		get
		{
			return this._ManualText;
		}
		set
		{
			this._ManualText = value;
			SetEditField("ManualText", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string HelpHTML
	{
		get
		{
			return this._HelpHTML;
		}
		set
		{
			this._HelpHTML = value;
			SetEditField("HelpHTML", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string HelpText
	{
		get
		{
			return this._HelpText;
		}
		set
		{
			this._HelpText = value;
			SetEditField("HelpText", value);
		}
	}

}

/// <summary>
/// 数据表：TInputSample
/// </summary>
public class TInputSample : Table<TInputSample>
{
	private long? _SampleId;
	private long? _SampleType;
	private string _ApplyTo;
	private string _Value;
	private int? _DisplayOrder;
	private DateTime? _CreateTime;
	private DateTime? _LastChangeTime;

	public TInputSample()
	{
		tableName = "TInputSample";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? SampleId
	{
		get
		{
			return this._SampleId;
		}
		set
		{
			this._SampleId = value;
		}
	}

	/// <summary>
	/// 字段说明：类型
	/// [可以为NULL]、
	/// </summary>
	public long? SampleType
	{
		get
		{
			return this._SampleType;
		}
		set
		{
			this._SampleType = value;
			SetEditField("SampleType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ApplyTo
	{
		get
		{
			return this._ApplyTo;
		}
		set
		{
			this._ApplyTo = value;
			SetEditField("ApplyTo", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string Value
	{
		get
		{
			return this._Value;
		}
		set
		{
			this._Value = value;
			SetEditField("Value", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? DisplayOrder
	{
		get
		{
			return this._DisplayOrder;
		}
		set
		{
			this._DisplayOrder = value;
			SetEditField("DisplayOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateTime
	{
		get
		{
			return this._CreateTime;
		}
		set
		{
			this._CreateTime = value;
			SetEditField("CreateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastChangeTime
	{
		get
		{
			return this._LastChangeTime;
		}
		set
		{
			this._LastChangeTime = value;
			SetEditField("LastChangeTime", value);
		}
	}

}

/// <summary>
/// 数据表：TInputTemplate
/// </summary>
public class TInputTemplate : Table<TInputTemplate>
{
	private long? _RecordId;
	private string _DocumentType;
	private string _ParentInputType;
	private string _InputType;
	private int? _ChildOrder;
	private string _Caption;
	private string _Description;
	private bool? _AllowAddChildren;
	private int? _MinChildrenCount;
	private int? _MinWordCount;
	private int? _MaxWordCount;
	private int? _InputSampleType;
	private int? _RequiredUIWidth;
	private string _UIType;
	private bool? _Optional;
	private string _OptionValues;
	private string _IframeUrl;

	public TInputTemplate()
	{
		tableName = "TInputTemplate";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
			SetEditField("RecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [不能为NULL]、
	/// </summary>
	public string DocumentType
	{
		get
		{
			return this._DocumentType;
		}
		set
		{
			this._DocumentType = value;
			SetEditField("DocumentType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ParentInputType
	{
		get
		{
			return this._ParentInputType;
		}
		set
		{
			this._ParentInputType = value;
			SetEditField("ParentInputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string InputType
	{
		get
		{
			return this._InputType;
		}
		set
		{
			this._InputType = value;
			SetEditField("InputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? ChildOrder
	{
		get
		{
			return this._ChildOrder;
		}
		set
		{
			this._ChildOrder = value;
			SetEditField("ChildOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Caption
	{
		get
		{
			return this._Caption;
		}
		set
		{
			this._Caption = value;
			SetEditField("Caption", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Description
	{
		get
		{
			return this._Description;
		}
		set
		{
			this._Description = value;
			SetEditField("Description", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public bool? AllowAddChildren
	{
		get
		{
			return this._AllowAddChildren;
		}
		set
		{
			this._AllowAddChildren = value;
			SetEditField("AllowAddChildren", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MinChildrenCount
	{
		get
		{
			return this._MinChildrenCount;
		}
		set
		{
			this._MinChildrenCount = value;
			SetEditField("MinChildrenCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MinWordCount
	{
		get
		{
			return this._MinWordCount;
		}
		set
		{
			this._MinWordCount = value;
			SetEditField("MinWordCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MaxWordCount
	{
		get
		{
			return this._MaxWordCount;
		}
		set
		{
			this._MaxWordCount = value;
			SetEditField("MaxWordCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? InputSampleType
	{
		get
		{
			return this._InputSampleType;
		}
		set
		{
			this._InputSampleType = value;
			SetEditField("InputSampleType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? RequiredUIWidth
	{
		get
		{
			return this._RequiredUIWidth;
		}
		set
		{
			this._RequiredUIWidth = value;
			SetEditField("RequiredUIWidth", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [不能为NULL]、
	/// </summary>
	public string UIType
	{
		get
		{
			return this._UIType;
		}
		set
		{
			this._UIType = value;
			SetEditField("UIType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public bool? Optional
	{
		get
		{
			return this._Optional;
		}
		set
		{
			this._Optional = value;
			SetEditField("Optional", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string OptionValues
	{
		get
		{
			return this._OptionValues;
		}
		set
		{
			this._OptionValues = value;
			SetEditField("OptionValues", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(100)]、  [可以为NULL]、
	/// </summary>
	public string IframeUrl
	{
		get
		{
			return this._IframeUrl;
		}
		set
		{
			this._IframeUrl = value;
			SetEditField("IframeUrl", value);
		}
	}

}

/// <summary>
/// 数据表：TInputTemplate_backup
/// </summary>
public class TInputTemplate_backup : Table<TInputTemplate_backup>
{
	private long? _RecordId;
	private string _DocumentType;
	private string _ParentInputType;
	private string _InputType;
	private int? _ChildOrder;
	private string _Caption;
	private string _Description;
	private bool? _AllowAddChildren;
	private int? _MinChildrenCount;
	private int? _MinWordCount;
	private int? _MaxWordCount;
	private int? _InputSampleType;
	private int? _RequiredUIWidth;
	private string _UIType;
	private bool? _Optional;
	private string _OptionValues;

	public TInputTemplate_backup()
	{
		tableName = "TInputTemplate_backup";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [不能为NULL]、
	/// </summary>
	public string DocumentType
	{
		get
		{
			return this._DocumentType;
		}
		set
		{
			this._DocumentType = value;
			SetEditField("DocumentType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ParentInputType
	{
		get
		{
			return this._ParentInputType;
		}
		set
		{
			this._ParentInputType = value;
			SetEditField("ParentInputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string InputType
	{
		get
		{
			return this._InputType;
		}
		set
		{
			this._InputType = value;
			SetEditField("InputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? ChildOrder
	{
		get
		{
			return this._ChildOrder;
		}
		set
		{
			this._ChildOrder = value;
			SetEditField("ChildOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Caption
	{
		get
		{
			return this._Caption;
		}
		set
		{
			this._Caption = value;
			SetEditField("Caption", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Description
	{
		get
		{
			return this._Description;
		}
		set
		{
			this._Description = value;
			SetEditField("Description", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public bool? AllowAddChildren
	{
		get
		{
			return this._AllowAddChildren;
		}
		set
		{
			this._AllowAddChildren = value;
			SetEditField("AllowAddChildren", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MinChildrenCount
	{
		get
		{
			return this._MinChildrenCount;
		}
		set
		{
			this._MinChildrenCount = value;
			SetEditField("MinChildrenCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MinWordCount
	{
		get
		{
			return this._MinWordCount;
		}
		set
		{
			this._MinWordCount = value;
			SetEditField("MinWordCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MaxWordCount
	{
		get
		{
			return this._MaxWordCount;
		}
		set
		{
			this._MaxWordCount = value;
			SetEditField("MaxWordCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? InputSampleType
	{
		get
		{
			return this._InputSampleType;
		}
		set
		{
			this._InputSampleType = value;
			SetEditField("InputSampleType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? RequiredUIWidth
	{
		get
		{
			return this._RequiredUIWidth;
		}
		set
		{
			this._RequiredUIWidth = value;
			SetEditField("RequiredUIWidth", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [不能为NULL]、
	/// </summary>
	public string UIType
	{
		get
		{
			return this._UIType;
		}
		set
		{
			this._UIType = value;
			SetEditField("UIType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public bool? Optional
	{
		get
		{
			return this._Optional;
		}
		set
		{
			this._Optional = value;
			SetEditField("Optional", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string OptionValues
	{
		get
		{
			return this._OptionValues;
		}
		set
		{
			this._OptionValues = value;
			SetEditField("OptionValues", value);
		}
	}

}

/// <summary>
/// 数据表：TInputTemplate_backup_20211127
/// </summary>
public class TInputTemplate_backup_20211127 : Table<TInputTemplate_backup_20211127>
{
	private long? _RecordId;
	private string _DocumentType;
	private string _ParentInputType;
	private string _InputType;
	private int? _ChildOrder;
	private string _Caption;
	private string _Description;
	private bool? _AllowAddChildren;
	private int? _MinChildrenCount;
	private int? _MinWordCount;
	private int? _MaxWordCount;
	private int? _InputSampleType;
	private int? _RequiredUIWidth;
	private string _UIType;
	private bool? _Optional;
	private string _OptionValues;

	public TInputTemplate_backup_20211127()
	{
		tableName = "TInputTemplate_backup_20211127";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
			SetEditField("RecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [不能为NULL]、
	/// </summary>
	public string DocumentType
	{
		get
		{
			return this._DocumentType;
		}
		set
		{
			this._DocumentType = value;
			SetEditField("DocumentType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ParentInputType
	{
		get
		{
			return this._ParentInputType;
		}
		set
		{
			this._ParentInputType = value;
			SetEditField("ParentInputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string InputType
	{
		get
		{
			return this._InputType;
		}
		set
		{
			this._InputType = value;
			SetEditField("InputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? ChildOrder
	{
		get
		{
			return this._ChildOrder;
		}
		set
		{
			this._ChildOrder = value;
			SetEditField("ChildOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Caption
	{
		get
		{
			return this._Caption;
		}
		set
		{
			this._Caption = value;
			SetEditField("Caption", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Description
	{
		get
		{
			return this._Description;
		}
		set
		{
			this._Description = value;
			SetEditField("Description", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public bool? AllowAddChildren
	{
		get
		{
			return this._AllowAddChildren;
		}
		set
		{
			this._AllowAddChildren = value;
			SetEditField("AllowAddChildren", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MinChildrenCount
	{
		get
		{
			return this._MinChildrenCount;
		}
		set
		{
			this._MinChildrenCount = value;
			SetEditField("MinChildrenCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MinWordCount
	{
		get
		{
			return this._MinWordCount;
		}
		set
		{
			this._MinWordCount = value;
			SetEditField("MinWordCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MaxWordCount
	{
		get
		{
			return this._MaxWordCount;
		}
		set
		{
			this._MaxWordCount = value;
			SetEditField("MaxWordCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? InputSampleType
	{
		get
		{
			return this._InputSampleType;
		}
		set
		{
			this._InputSampleType = value;
			SetEditField("InputSampleType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? RequiredUIWidth
	{
		get
		{
			return this._RequiredUIWidth;
		}
		set
		{
			this._RequiredUIWidth = value;
			SetEditField("RequiredUIWidth", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [不能为NULL]、
	/// </summary>
	public string UIType
	{
		get
		{
			return this._UIType;
		}
		set
		{
			this._UIType = value;
			SetEditField("UIType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public bool? Optional
	{
		get
		{
			return this._Optional;
		}
		set
		{
			this._Optional = value;
			SetEditField("Optional", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string OptionValues
	{
		get
		{
			return this._OptionValues;
		}
		set
		{
			this._OptionValues = value;
			SetEditField("OptionValues", value);
		}
	}

}

/// <summary>
/// 数据表：TInputTemplateV5
/// </summary>
public class TInputTemplateV5 : Table<TInputTemplateV5>
{
	private long? _RecordId;
	private string _DocumentType;
	private string _ParentInputType;
	private string _InputType;
	private int? _ChildOrder;
	private string _Caption;
	private string _Description;
	private bool? _AllowAddChildren;
	private int? _MinChildrenCount;
	private int? _MinWordCount;
	private int? _MaxWordCount;
	private int? _InputSampleType;
	private int? _RequiredUIWidth;
	private string _UIType;
	private bool? _Optional;
	private string _OptionValues;
	private string _IframeUrl;

	public TInputTemplateV5()
	{
		tableName = "TInputTemplateV5";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
			SetEditField("RecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [不能为NULL]、
	/// </summary>
	public string DocumentType
	{
		get
		{
			return this._DocumentType;
		}
		set
		{
			this._DocumentType = value;
			SetEditField("DocumentType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ParentInputType
	{
		get
		{
			return this._ParentInputType;
		}
		set
		{
			this._ParentInputType = value;
			SetEditField("ParentInputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string InputType
	{
		get
		{
			return this._InputType;
		}
		set
		{
			this._InputType = value;
			SetEditField("InputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? ChildOrder
	{
		get
		{
			return this._ChildOrder;
		}
		set
		{
			this._ChildOrder = value;
			SetEditField("ChildOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Caption
	{
		get
		{
			return this._Caption;
		}
		set
		{
			this._Caption = value;
			SetEditField("Caption", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Description
	{
		get
		{
			return this._Description;
		}
		set
		{
			this._Description = value;
			SetEditField("Description", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public bool? AllowAddChildren
	{
		get
		{
			return this._AllowAddChildren;
		}
		set
		{
			this._AllowAddChildren = value;
			SetEditField("AllowAddChildren", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MinChildrenCount
	{
		get
		{
			return this._MinChildrenCount;
		}
		set
		{
			this._MinChildrenCount = value;
			SetEditField("MinChildrenCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MinWordCount
	{
		get
		{
			return this._MinWordCount;
		}
		set
		{
			this._MinWordCount = value;
			SetEditField("MinWordCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? MaxWordCount
	{
		get
		{
			return this._MaxWordCount;
		}
		set
		{
			this._MaxWordCount = value;
			SetEditField("MaxWordCount", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? InputSampleType
	{
		get
		{
			return this._InputSampleType;
		}
		set
		{
			this._InputSampleType = value;
			SetEditField("InputSampleType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? RequiredUIWidth
	{
		get
		{
			return this._RequiredUIWidth;
		}
		set
		{
			this._RequiredUIWidth = value;
			SetEditField("RequiredUIWidth", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [不能为NULL]、
	/// </summary>
	public string UIType
	{
		get
		{
			return this._UIType;
		}
		set
		{
			this._UIType = value;
			SetEditField("UIType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public bool? Optional
	{
		get
		{
			return this._Optional;
		}
		set
		{
			this._Optional = value;
			SetEditField("Optional", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string OptionValues
	{
		get
		{
			return this._OptionValues;
		}
		set
		{
			this._OptionValues = value;
			SetEditField("OptionValues", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(100)]、  [可以为NULL]、
	/// </summary>
	public string IframeUrl
	{
		get
		{
			return this._IframeUrl;
		}
		set
		{
			this._IframeUrl = value;
			SetEditField("IframeUrl", value);
		}
	}

}

/// <summary>
/// 数据表：TInputUploadFile
/// </summary>
public class TInputUploadFile : Table<TInputUploadFile>
{
	private long? _UploadFileId;
	private long? _DocumentId;
	private long? _InputValueRecordId;
	private string _OriginalFileName;
	private DateTime? _UploadTime;
	private long? _UploadUserId;
	private string _LocationName;
	private string _Subfolder;
	private string _FileName;

	public TInputUploadFile()
	{
		tableName = "TInputUploadFile";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? UploadFileId
	{
		get
		{
			return this._UploadFileId;
		}
		set
		{
			this._UploadFileId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? InputValueRecordId
	{
		get
		{
			return this._InputValueRecordId;
		}
		set
		{
			this._InputValueRecordId = value;
			SetEditField("InputValueRecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string OriginalFileName
	{
		get
		{
			return this._OriginalFileName;
		}
		set
		{
			this._OriginalFileName = value;
			SetEditField("OriginalFileName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? UploadTime
	{
		get
		{
			return this._UploadTime;
		}
		set
		{
			this._UploadTime = value;
			SetEditField("UploadTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? UploadUserId
	{
		get
		{
			return this._UploadUserId;
		}
		set
		{
			this._UploadUserId = value;
			SetEditField("UploadUserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(250)]、  [可以为NULL]、
	/// </summary>
	public string LocationName
	{
		get
		{
			return this._LocationName;
		}
		set
		{
			this._LocationName = value;
			SetEditField("LocationName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string Subfolder
	{
		get
		{
			return this._Subfolder;
		}
		set
		{
			this._Subfolder = value;
			SetEditField("Subfolder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(100)]、  [可以为NULL]、
	/// </summary>
	public string FileName
	{
		get
		{
			return this._FileName;
		}
		set
		{
			this._FileName = value;
			SetEditField("FileName", value);
		}
	}

}

/// <summary>
/// 数据表：TInputValue
/// </summary>
public class TInputValue : Table<TInputValue>
{
	private long? _RecordId;
	private long? _ParentRecordId;
	private long? _DocumentId;
	private string _ParentInputType_unused;
	private string _InputType;
	private string _Value;
	private int? _ChildOrder;
	private DateTime? _CreateTime;
	private DateTime? _LastChangTime;
	private string _Value_bak;
	private bool? _InputByUpload;

	public TInputValue()
	{
		tableName = "TInputValue";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
			SetEditField("RecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? ParentRecordId
	{
		get
		{
			return this._ParentRecordId;
		}
		set
		{
			this._ParentRecordId = value;
			SetEditField("ParentRecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ParentInputType_unused
	{
		get
		{
			return this._ParentInputType_unused;
		}
		set
		{
			this._ParentInputType_unused = value;
			SetEditField("ParentInputType_unused", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string InputType
	{
		get
		{
			return this._InputType;
		}
		set
		{
			this._InputType = value;
			SetEditField("InputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string Value
	{
		get
		{
			return this._Value;
		}
		set
		{
			this._Value = value;
			SetEditField("Value", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? ChildOrder
	{
		get
		{
			return this._ChildOrder;
		}
		set
		{
			this._ChildOrder = value;
			SetEditField("ChildOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateTime
	{
		get
		{
			return this._CreateTime;
		}
		set
		{
			this._CreateTime = value;
			SetEditField("CreateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastChangTime
	{
		get
		{
			return this._LastChangTime;
		}
		set
		{
			this._LastChangTime = value;
			SetEditField("LastChangTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string Value_bak
	{
		get
		{
			return this._Value_bak;
		}
		set
		{
			this._Value_bak = value;
			SetEditField("Value_bak", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public bool? InputByUpload
	{
		get
		{
			return this._InputByUpload;
		}
		set
		{
			this._InputByUpload = value;
			SetEditField("InputByUpload", value);
		}
	}

}

/// <summary>
/// 数据表：TInputValue_backup
/// </summary>
public class TInputValue_backup : Table<TInputValue_backup>
{
	private long? _RecordId;
	private long? _ParentRecordId;
	private long? _DocumentId;
	private string _ParentInputType_unused;
	private string _InputType;
	private string _Value;
	private int? _ChildOrder;
	private DateTime? _CreateTime;
	private DateTime? _LastChangTime;
	private string _Value_bak;

	public TInputValue_backup()
	{
		tableName = "TInputValue_backup";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
			SetEditField("RecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? ParentRecordId
	{
		get
		{
			return this._ParentRecordId;
		}
		set
		{
			this._ParentRecordId = value;
			SetEditField("ParentRecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ParentInputType_unused
	{
		get
		{
			return this._ParentInputType_unused;
		}
		set
		{
			this._ParentInputType_unused = value;
			SetEditField("ParentInputType_unused", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string InputType
	{
		get
		{
			return this._InputType;
		}
		set
		{
			this._InputType = value;
			SetEditField("InputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string Value
	{
		get
		{
			return this._Value;
		}
		set
		{
			this._Value = value;
			SetEditField("Value", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? ChildOrder
	{
		get
		{
			return this._ChildOrder;
		}
		set
		{
			this._ChildOrder = value;
			SetEditField("ChildOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateTime
	{
		get
		{
			return this._CreateTime;
		}
		set
		{
			this._CreateTime = value;
			SetEditField("CreateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastChangTime
	{
		get
		{
			return this._LastChangTime;
		}
		set
		{
			this._LastChangTime = value;
			SetEditField("LastChangTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string Value_bak
	{
		get
		{
			return this._Value_bak;
		}
		set
		{
			this._Value_bak = value;
			SetEditField("Value_bak", value);
		}
	}

}

/// <summary>
/// 数据表：TInputValue_backup_20211127
/// </summary>
public class TInputValue_backup_20211127 : Table<TInputValue_backup_20211127>
{
	private long? _RecordId;
	private long? _ParentRecordId;
	private long? _DocumentId;
	private string _ParentInputType_unused;
	private string _InputType;
	private string _Value;
	private int? _ChildOrder;
	private DateTime? _CreateTime;
	private DateTime? _LastChangTime;
	private string _Value_bak;
	private bool? _InputByUpload;

	public TInputValue_backup_20211127()
	{
		tableName = "TInputValue_backup_20211127";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
			SetEditField("RecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? ParentRecordId
	{
		get
		{
			return this._ParentRecordId;
		}
		set
		{
			this._ParentRecordId = value;
			SetEditField("ParentRecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ParentInputType_unused
	{
		get
		{
			return this._ParentInputType_unused;
		}
		set
		{
			this._ParentInputType_unused = value;
			SetEditField("ParentInputType_unused", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string InputType
	{
		get
		{
			return this._InputType;
		}
		set
		{
			this._InputType = value;
			SetEditField("InputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string Value
	{
		get
		{
			return this._Value;
		}
		set
		{
			this._Value = value;
			SetEditField("Value", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? ChildOrder
	{
		get
		{
			return this._ChildOrder;
		}
		set
		{
			this._ChildOrder = value;
			SetEditField("ChildOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateTime
	{
		get
		{
			return this._CreateTime;
		}
		set
		{
			this._CreateTime = value;
			SetEditField("CreateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastChangTime
	{
		get
		{
			return this._LastChangTime;
		}
		set
		{
			this._LastChangTime = value;
			SetEditField("LastChangTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string Value_bak
	{
		get
		{
			return this._Value_bak;
		}
		set
		{
			this._Value_bak = value;
			SetEditField("Value_bak", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public bool? InputByUpload
	{
		get
		{
			return this._InputByUpload;
		}
		set
		{
			this._InputByUpload = value;
			SetEditField("InputByUpload", value);
		}
	}

}

/// <summary>
/// 数据表：TInputValueHistory
/// </summary>
public class TInputValueHistory : Table<TInputValueHistory>
{
	private long? _VersionNo;
	private long? _RecordId;
	private long? _ParentRecordId;
	private long? _DocumentId;
	private string _ParentInputType_unused;
	private string _InputType;
	private string _Value;
	private int? _ChildOrder;
	private DateTime? _CreateTime;
	private DateTime? _LastChangTime;
	private string _Value_bak;
	private bool? _InputByUpload;

	public TInputValueHistory()
	{
		tableName = "TInputValueHistory";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? VersionNo
	{
		get
		{
			return this._VersionNo;
		}
		set
		{
			this._VersionNo = value;
			SetEditField("VersionNo", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
			SetEditField("RecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? ParentRecordId
	{
		get
		{
			return this._ParentRecordId;
		}
		set
		{
			this._ParentRecordId = value;
			SetEditField("ParentRecordId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? DocumentId
	{
		get
		{
			return this._DocumentId;
		}
		set
		{
			this._DocumentId = value;
			SetEditField("DocumentId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ParentInputType_unused
	{
		get
		{
			return this._ParentInputType_unused;
		}
		set
		{
			this._ParentInputType_unused = value;
			SetEditField("ParentInputType_unused", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string InputType
	{
		get
		{
			return this._InputType;
		}
		set
		{
			this._InputType = value;
			SetEditField("InputType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string Value
	{
		get
		{
			return this._Value;
		}
		set
		{
			this._Value = value;
			SetEditField("Value", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? ChildOrder
	{
		get
		{
			return this._ChildOrder;
		}
		set
		{
			this._ChildOrder = value;
			SetEditField("ChildOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateTime
	{
		get
		{
			return this._CreateTime;
		}
		set
		{
			this._CreateTime = value;
			SetEditField("CreateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastChangTime
	{
		get
		{
			return this._LastChangTime;
		}
		set
		{
			this._LastChangTime = value;
			SetEditField("LastChangTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(-1)]、  [可以为NULL]、
	/// </summary>
	public string Value_bak
	{
		get
		{
			return this._Value_bak;
		}
		set
		{
			this._Value_bak = value;
			SetEditField("Value_bak", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public bool? InputByUpload
	{
		get
		{
			return this._InputByUpload;
		}
		set
		{
			this._InputByUpload = value;
			SetEditField("InputByUpload", value);
		}
	}

}

/// <summary>
/// 数据表：TPasswordReset
/// </summary>
public class TPasswordReset : Table<TPasswordReset>
{
	private int? _RecordId;
	private string _UserName;
	private DateTime? _CreateTime;
	private string _SentMsgValidCode;
	private DateTime? _ResetTime;

	public TPasswordReset()
	{
		tableName = "TPasswordReset";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public int? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [可以为NULL]、
	/// </summary>
	public string UserName
	{
		get
		{
			return this._UserName;
		}
		set
		{
			this._UserName = value;
			SetEditField("UserName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateTime
	{
		get
		{
			return this._CreateTime;
		}
		set
		{
			this._CreateTime = value;
			SetEditField("CreateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [可以为NULL]、
	/// </summary>
	public string SentMsgValidCode
	{
		get
		{
			return this._SentMsgValidCode;
		}
		set
		{
			this._SentMsgValidCode = value;
			SetEditField("SentMsgValidCode", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? ResetTime
	{
		get
		{
			return this._ResetTime;
		}
		set
		{
			this._ResetTime = value;
			SetEditField("ResetTime", value);
		}
	}

}

/// <summary>
/// 数据表：TSampleDocumentProcessLog_unused
/// </summary>
public class TSampleDocumentProcessLog_unused : Table<TSampleDocumentProcessLog_unused>
{
	private long? _UploadId;
	private DateTime? _CreateTime;
	private string _FileName;
	private int? _Status;
	private string _ErrorMessage;

	public TSampleDocumentProcessLog_unused()
	{
		tableName = "TSampleDocumentProcessLog_unused";
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? UploadId
	{
		get
		{
			return this._UploadId;
		}
		set
		{
			this._UploadId = value;
			SetEditField("UploadId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateTime
	{
		get
		{
			return this._CreateTime;
		}
		set
		{
			this._CreateTime = value;
			SetEditField("CreateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(150)]、  [可以为NULL]、
	/// </summary>
	public string FileName
	{
		get
		{
			return this._FileName;
		}
		set
		{
			this._FileName = value;
			SetEditField("FileName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? Status
	{
		get
		{
			return this._Status;
		}
		set
		{
			this._Status = value;
			SetEditField("Status", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ErrorMessage
	{
		get
		{
			return this._ErrorMessage;
		}
		set
		{
			this._ErrorMessage = value;
			SetEditField("ErrorMessage", value);
		}
	}

}

/// <summary>
/// 数据表：TSampleDocumentUpload_unused
/// </summary>
public class TSampleDocumentUpload_unused : Table<TSampleDocumentUpload_unused>
{
	private long? _RecordId;
	private int? _UserId;
	private bool? _IsPublic;
	private DateTime? _UploadTime;
	private string _RawFileName;
	private string _FileExt;
	private string _StorePath;
	private int? _Status;
	private DateTime? _ProcessTime;
	private string _ProcessErrorMessage;

	public TSampleDocumentUpload_unused()
	{
		tableName = "TSampleDocumentUpload_unused";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? UserId
	{
		get
		{
			return this._UserId;
		}
		set
		{
			this._UserId = value;
			SetEditField("UserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public bool? IsPublic
	{
		get
		{
			return this._IsPublic;
		}
		set
		{
			this._IsPublic = value;
			SetEditField("IsPublic", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? UploadTime
	{
		get
		{
			return this._UploadTime;
		}
		set
		{
			this._UploadTime = value;
			SetEditField("UploadTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string RawFileName
	{
		get
		{
			return this._RawFileName;
		}
		set
		{
			this._RawFileName = value;
			SetEditField("RawFileName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(10)]、  [可以为NULL]、
	/// </summary>
	public string FileExt
	{
		get
		{
			return this._FileExt;
		}
		set
		{
			this._FileExt = value;
			SetEditField("FileExt", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(250)]、  [可以为NULL]、
	/// </summary>
	public string StorePath
	{
		get
		{
			return this._StorePath;
		}
		set
		{
			this._StorePath = value;
			SetEditField("StorePath", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? Status
	{
		get
		{
			return this._Status;
		}
		set
		{
			this._Status = value;
			SetEditField("Status", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? ProcessTime
	{
		get
		{
			return this._ProcessTime;
		}
		set
		{
			this._ProcessTime = value;
			SetEditField("ProcessTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ProcessErrorMessage
	{
		get
		{
			return this._ProcessErrorMessage;
		}
		set
		{
			this._ProcessErrorMessage = value;
			SetEditField("ProcessErrorMessage", value);
		}
	}

}

/// <summary>
/// 数据表：TSystemImage
/// </summary>
public class TSystemImage : Table<TSystemImage>
{
	private long? _ImageId;
	private string _Type;
	private int? _UploadUserId;
	private string _Directory;
	private string _FileName;
	private DateTime? _UploadTime;
	private int? _DisplayOrder;
	private string _Description;

	public TSystemImage()
	{
		tableName = "TSystemImage";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? ImageId
	{
		get
		{
			return this._ImageId;
		}
		set
		{
			this._ImageId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string Type
	{
		get
		{
			return this._Type;
		}
		set
		{
			this._Type = value;
			SetEditField("Type", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public int? UploadUserId
	{
		get
		{
			return this._UploadUserId;
		}
		set
		{
			this._UploadUserId = value;
			SetEditField("UploadUserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(250)]、  [不能为NULL]、
	/// </summary>
	public string Directory
	{
		get
		{
			return this._Directory;
		}
		set
		{
			this._Directory = value;
			SetEditField("Directory", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [不能为NULL]、
	/// </summary>
	public string FileName
	{
		get
		{
			return this._FileName;
		}
		set
		{
			this._FileName = value;
			SetEditField("FileName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// 默认值：(getdate())
	/// </summary>
	public DateTime? UploadTime
	{
		get
		{
			return this._UploadTime;
		}
		set
		{
			this._UploadTime = value;
			SetEditField("UploadTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? DisplayOrder
	{
		get
		{
			return this._DisplayOrder;
		}
		set
		{
			this._DisplayOrder = value;
			SetEditField("DisplayOrder", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Description
	{
		get
		{
			return this._Description;
		}
		set
		{
			this._Description = value;
			SetEditField("Description", value);
		}
	}

}

/// <summary>
/// 数据表：TUploadLocation
/// </summary>
public class TUploadLocation : Table<TUploadLocation>
{
	private string _LocationName;
	private string _LocationPath;
	private bool? _AsDefault;

	public TUploadLocation()
	{
		tableName = "TUploadLocation";
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(30)]、  [不能为NULL]、
	/// </summary>
	public string LocationName
	{
		get
		{
			return this._LocationName;
		}
		set
		{
			this._LocationName = value;
			SetEditField("LocationName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(255)]、  [不能为NULL]、
	/// </summary>
	public string LocationPath
	{
		get
		{
			return this._LocationPath;
		}
		set
		{
			this._LocationPath = value;
			SetEditField("LocationPath", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public bool? AsDefault
	{
		get
		{
			return this._AsDefault;
		}
		set
		{
			this._AsDefault = value;
			SetEditField("AsDefault", value);
		}
	}

}

/// <summary>
/// 数据表：TUserAuthorizationApply
/// </summary>
public class TUserAuthorizationApply : Table<TUserAuthorizationApply>
{
	private long? _RecordId;
	private long? _UserId;
	private DateTime? _CreateTime;
	private int? _CreatedByUserId;
	private string _AuthorizeTo;
	private DateTime? _ExpireDate;
	private string _Description;
	private int? _ApprovedStatus;
	private int? _ApprovedByUserId;
	private DateTime? _ApprovedTime;
	private string _AuthCode;

	public TUserAuthorizationApply()
	{
		tableName = "TUserAuthorizationApply";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public long? RecordId
	{
		get
		{
			return this._RecordId;
		}
		set
		{
			this._RecordId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public long? UserId
	{
		get
		{
			return this._UserId;
		}
		set
		{
			this._UserId = value;
			SetEditField("UserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateTime
	{
		get
		{
			return this._CreateTime;
		}
		set
		{
			this._CreateTime = value;
			SetEditField("CreateTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? CreatedByUserId
	{
		get
		{
			return this._CreatedByUserId;
		}
		set
		{
			this._CreatedByUserId = value;
			SetEditField("CreatedByUserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string AuthorizeTo
	{
		get
		{
			return this._AuthorizeTo;
		}
		set
		{
			this._AuthorizeTo = value;
			SetEditField("AuthorizeTo", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? ExpireDate
	{
		get
		{
			return this._ExpireDate;
		}
		set
		{
			this._ExpireDate = value;
			SetEditField("ExpireDate", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Description
	{
		get
		{
			return this._Description;
		}
		set
		{
			this._Description = value;
			SetEditField("Description", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// 默认值：((0))
	/// </summary>
	public int? ApprovedStatus
	{
		get
		{
			return this._ApprovedStatus;
		}
		set
		{
			this._ApprovedStatus = value;
			SetEditField("ApprovedStatus", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? ApprovedByUserId
	{
		get
		{
			return this._ApprovedByUserId;
		}
		set
		{
			this._ApprovedByUserId = value;
			SetEditField("ApprovedByUserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? ApprovedTime
	{
		get
		{
			return this._ApprovedTime;
		}
		set
		{
			this._ApprovedTime = value;
			SetEditField("ApprovedTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(1000)]、  [可以为NULL]、
	/// </summary>
	public string AuthCode
	{
		get
		{
			return this._AuthCode;
		}
		set
		{
			this._AuthCode = value;
			SetEditField("AuthCode", value);
		}
	}

}

/// <summary>
/// 数据表：TVideo
/// </summary>
public class TVideo : Table<TVideo>
{
	private int? _VideoId;
	private string _Title;
	private DateTime? _UploadTime;
	private long? _UploadUserId;
	private string _FileName;
	private string _PictureFileName;
	private string _DescriptionHtml;
	private string _DescriptionText;

	public TVideo()
	{
		tableName = "TVideo";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public int? VideoId
	{
		get
		{
			return this._VideoId;
		}
		set
		{
			this._VideoId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string Title
	{
		get
		{
			return this._Title;
		}
		set
		{
			this._Title = value;
			SetEditField("Title", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? UploadTime
	{
		get
		{
			return this._UploadTime;
		}
		set
		{
			this._UploadTime = value;
			SetEditField("UploadTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public long? UploadUserId
	{
		get
		{
			return this._UploadUserId;
		}
		set
		{
			this._UploadUserId = value;
			SetEditField("UploadUserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [可以为NULL]、
	/// </summary>
	public string FileName
	{
		get
		{
			return this._FileName;
		}
		set
		{
			this._FileName = value;
			SetEditField("FileName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(50)]、  [可以为NULL]、
	/// </summary>
	public string PictureFileName
	{
		get
		{
			return this._PictureFileName;
		}
		set
		{
			this._PictureFileName = value;
			SetEditField("PictureFileName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string DescriptionHtml
	{
		get
		{
			return this._DescriptionHtml;
		}
		set
		{
			this._DescriptionHtml = value;
			SetEditField("DescriptionHtml", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string DescriptionText
	{
		get
		{
			return this._DescriptionText;
		}
		set
		{
			this._DescriptionText = value;
			SetEditField("DescriptionText", value);
		}
	}

}

/// <summary>
/// 数据表：UserProfile
/// </summary>
public class UserProfile : Table<UserProfile>
{
	private int? _UserId;
	private string _UserName;
	private string _RealName;
	private string _Email;
	private string _Tel;
	private DateTime? _RegisterTime;
	private DateTime? _LastLoginTime;
	private string _UserType;
	private int? _CustomerServiceId;
	private int? _ConfirmStatus;

	public UserProfile()
	{
		tableName = "UserProfile";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public int? UserId
	{
		get
		{
			return this._UserId;
		}
		set
		{
			this._UserId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string UserName
	{
		get
		{
			return this._UserName;
		}
		set
		{
			this._UserName = value;
			SetEditField("UserName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string RealName
	{
		get
		{
			return this._RealName;
		}
		set
		{
			this._RealName = value;
			SetEditField("RealName", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(30)]、  [可以为NULL]、
	/// </summary>
	public string Email
	{
		get
		{
			return this._Email;
		}
		set
		{
			this._Email = value;
			SetEditField("Email", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string Tel
	{
		get
		{
			return this._Tel;
		}
		set
		{
			this._Tel = value;
			SetEditField("Tel", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? RegisterTime
	{
		get
		{
			return this._RegisterTime;
		}
		set
		{
			this._RegisterTime = value;
			SetEditField("RegisterTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastLoginTime
	{
		get
		{
			return this._LastLoginTime;
		}
		set
		{
			this._LastLoginTime = value;
			SetEditField("LastLoginTime", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [varchar(20)]、  [可以为NULL]、
	/// </summary>
	public string UserType
	{
		get
		{
			return this._UserType;
		}
		set
		{
			this._UserType = value;
			SetEditField("UserType", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? CustomerServiceId
	{
		get
		{
			return this._CustomerServiceId;
		}
		set
		{
			this._CustomerServiceId = value;
			SetEditField("CustomerServiceId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public int? ConfirmStatus
	{
		get
		{
			return this._ConfirmStatus;
		}
		set
		{
			this._ConfirmStatus = value;
			SetEditField("ConfirmStatus", value);
		}
	}

}

/// <summary>
/// 数据表：webpages_Membership
/// </summary>
public class webpages_Membership : Table<webpages_Membership>
{
	private int? _UserId;
	private DateTime? _CreateDate;
	private string _ConfirmationToken;
	private bool? _IsConfirmed;
	private DateTime? _LastPasswordFailureDate;
	private int? _PasswordFailuresSinceLastSuccess;
	private string _Password;
	private DateTime? _PasswordChangedDate;
	private string _PasswordSalt;
	private string _PasswordVerificationToken;
	private DateTime? _PasswordVerificationTokenExpirationDate;

	public webpages_Membership()
	{
		tableName = "webpages_Membership";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public int? UserId
	{
		get
		{
			return this._UserId;
		}
		set
		{
			this._UserId = value;
			SetEditField("UserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? CreateDate
	{
		get
		{
			return this._CreateDate;
		}
		set
		{
			this._CreateDate = value;
			SetEditField("CreateDate", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string ConfirmationToken
	{
		get
		{
			return this._ConfirmationToken;
		}
		set
		{
			this._ConfirmationToken = value;
			SetEditField("ConfirmationToken", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// 默认值：((0))
	/// </summary>
	public bool? IsConfirmed
	{
		get
		{
			return this._IsConfirmed;
		}
		set
		{
			this._IsConfirmed = value;
			SetEditField("IsConfirmed", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? LastPasswordFailureDate
	{
		get
		{
			return this._LastPasswordFailureDate;
		}
		set
		{
			this._LastPasswordFailureDate = value;
			SetEditField("LastPasswordFailureDate", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// 默认值：((0))
	/// </summary>
	public int? PasswordFailuresSinceLastSuccess
	{
		get
		{
			return this._PasswordFailuresSinceLastSuccess;
		}
		set
		{
			this._PasswordFailuresSinceLastSuccess = value;
			SetEditField("PasswordFailuresSinceLastSuccess", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string Password
	{
		get
		{
			return this._Password;
		}
		set
		{
			this._Password = value;
			SetEditField("Password", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? PasswordChangedDate
	{
		get
		{
			return this._PasswordChangedDate;
		}
		set
		{
			this._PasswordChangedDate = value;
			SetEditField("PasswordChangedDate", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string PasswordSalt
	{
		get
		{
			return this._PasswordSalt;
		}
		set
		{
			this._PasswordSalt = value;
			SetEditField("PasswordSalt", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public string PasswordVerificationToken
	{
		get
		{
			return this._PasswordVerificationToken;
		}
		set
		{
			this._PasswordVerificationToken = value;
			SetEditField("PasswordVerificationToken", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [可以为NULL]、
	/// </summary>
	public DateTime? PasswordVerificationTokenExpirationDate
	{
		get
		{
			return this._PasswordVerificationTokenExpirationDate;
		}
		set
		{
			this._PasswordVerificationTokenExpirationDate = value;
			SetEditField("PasswordVerificationTokenExpirationDate", value);
		}
	}

}

/// <summary>
/// 数据表：webpages_OAuthMembership
/// </summary>
public class webpages_OAuthMembership : Table<webpages_OAuthMembership>
{
	private string _Provider;
	private string _ProviderUserId;
	private int? _UserId;

	public webpages_OAuthMembership()
	{
		tableName = "webpages_OAuthMembership";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string Provider
	{
		get
		{
			return this._Provider;
		}
		set
		{
			this._Provider = value;
			SetEditField("Provider", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string ProviderUserId
	{
		get
		{
			return this._ProviderUserId;
		}
		set
		{
			this._ProviderUserId = value;
			SetEditField("ProviderUserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public int? UserId
	{
		get
		{
			return this._UserId;
		}
		set
		{
			this._UserId = value;
			SetEditField("UserId", value);
		}
	}

}

/// <summary>
/// 数据表：webpages_Roles
/// </summary>
public class webpages_Roles : Table<webpages_Roles>
{
	private int? _RoleId;
	private string _RoleName;

	public webpages_Roles()
	{
		tableName = "webpages_Roles";
	}

	/// <summary>
	/// 字段说明：
	/// [标识字段]、 [不能为NULL]、
	/// </summary>
	public int? RoleId
	{
		get
		{
			return this._RoleId;
		}
		set
		{
			this._RoleId = value;
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public string RoleName
	{
		get
		{
			return this._RoleName;
		}
		set
		{
			this._RoleName = value;
			SetEditField("RoleName", value);
		}
	}

}

/// <summary>
/// 数据表：webpages_UsersInRoles
/// </summary>
public class webpages_UsersInRoles : Table<webpages_UsersInRoles>
{
	private int? _UserId;
	private int? _RoleId;

	public webpages_UsersInRoles()
	{
		tableName = "webpages_UsersInRoles";
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public int? UserId
	{
		get
		{
			return this._UserId;
		}
		set
		{
			this._UserId = value;
			SetEditField("UserId", value);
		}
	}

	/// <summary>
	/// 字段说明：
	/// [不能为NULL]、
	/// </summary>
	public int? RoleId
	{
		get
		{
			return this._RoleId;
		}
		set
		{
			this._RoleId = value;
			SetEditField("RoleId", value);
		}
	}

}


    /// <summary>
    /// 数据表：WeixinLoginTokens
    /// </summary>
    public class WeixinLoginTokens : Table<WeixinLoginTokens>
    {
        private string _Token;
        private DateTime? _CreateTime;
        private string _OpenId;
        private DateTime? _AuthorizeTme;
        private bool? _Logined;

        public WeixinLoginTokens()
        {
            tableName = "WeixinLoginTokens";
        }

        /// <summary>
        /// 字段说明：
        /// [varchar(50)]、  [不能为NULL]、
        /// </summary>
        public string Token
        {
            get
            {
                return this._Token;
            }
            set
            {
                this._Token = value;
                SetEditField("Token", value);
            }
        }

        /// <summary>
        /// 字段说明：
        /// [可以为NULL]、
        /// 默认值：(NULL)
        /// </summary>
        public DateTime? CreateTime
        {
            get
            {
                return this._CreateTime;
            }
            set
            {
                this._CreateTime = value;
                SetEditField("CreateTime", value);
            }
        }

        /// <summary>
        /// 字段说明：
        /// [varchar(50)]、  [可以为NULL]、
        /// 默认值：(NULL)
        /// </summary>
        public string OpenId
        {
            get
            {
                return this._OpenId;
            }
            set
            {
                this._OpenId = value;
                SetEditField("OpenId", value);
            }
        }

        /// <summary>
        /// 字段说明：
        /// [可以为NULL]、
        /// 默认值：(NULL)
        /// </summary>
        public DateTime? AuthorizeTme
        {
            get
            {
                return this._AuthorizeTme;
            }
            set
            {
                this._AuthorizeTme = value;
                SetEditField("AuthorizeTme", value);
            }
        }

        /// <summary>
        /// 字段说明：
        /// [可以为NULL]、
        /// 默认值：(NULL)
        /// </summary>
        public bool? Logined
        {
            get
            {
                return this._Logined;
            }
            set
            {
                this._Logined = value;
                SetEditField("Logined", value);
            }
        }

    }

    /// <summary>
    /// 视图：V_Document_Entity
    /// </summary>
    public class V_Document_Entity : View<V_Document_Entity>
{
	public long? DocumentId;
	public string DocumentType;
	public long? UserId;
	public string Title;
	public string Description;
	public DateTime? CreateTime;
	public DateTime? LastChangeTime;
	public string StatusCode;
	public string StatusName;
	public string UserName;
	public string DocumentTypeName;
}

/// <summary>
/// 视图：V_SampleDocument_Entity
/// </summary>
public class V_SampleDocument_Entity : View<V_SampleDocument_Entity>
{
	public long? RecordId;
	public int? UserId;
	public bool? IsPublic;
	public string IsPublicText;
	public DateTime? UploadTime;
	public string RawFileName;
	public string FileExt;
	public int? Status;
	public DateTime? ProcessTime;
	public string ProcessErrorMessage;
	public string UserName;
}

public class Procedures
{
	public static int sp_CheckInvalidTemplateNode(out DataSet ds, string DocumentType)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_CheckInvalidTemplateNode @DocumentType  ";
		sql+="SELECT @r as  r ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		paras.Add(Sql.CreateDbParameter("@DocumentType",DocumentType));
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_CheckInvalidTemplateNode(string DocumentType)
	{
		DataSet ds;
		return sp_CheckInvalidTemplateNode(out ds, DocumentType);
	}

	public static int sp_DeleteDecendantValueRecordsById(out DataSet ds, long? DocumentId, long? RecordId, ref string ErrorMessage)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_DeleteDecendantValueRecordsById @DocumentId,@RecordId,@ErrorMessage OUTPUT  ";
		sql+="SELECT @r as  r, @ErrorMessage as [ErrorMessage] ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		paras.Add(Sql.CreateDbParameter("@DocumentId",DocumentId));
		paras.Add(Sql.CreateDbParameter("@RecordId",RecordId));
		paras.Add(Sql.CreateDbParameter("@ErrorMessage",ErrorMessage,ParameterDirection.Output));
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			ErrorMessage = dr["ErrorMessage"]== DBNull.Value ? null : Convert.ToString(dr["ErrorMessage"]);
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_DeleteDecendantValueRecordsById(long? DocumentId, long? RecordId, ref string ErrorMessage)
	{
		DataSet ds;
		return sp_DeleteDecendantValueRecordsById(out ds, DocumentId, RecordId, ref ErrorMessage);
	}

	public static int sp_DeleteDocumentById(out DataSet ds, long? DocumentId)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_DeleteDocumentById @DocumentId  ";
		sql+="SELECT @r as  r ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		paras.Add(Sql.CreateDbParameter("@DocumentId",DocumentId));
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_DeleteDocumentById(long? DocumentId)
	{
		DataSet ds;
		return sp_DeleteDocumentById(out ds, DocumentId);
	}

	public static int sp_DeleteInputValueById(out DataSet ds, long? DocumentId, long? RecordId, ref string ErrorMessage)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_DeleteInputValueById @DocumentId,@RecordId,@ErrorMessage OUTPUT  ";
		sql+="SELECT @r as  r, @ErrorMessage as [ErrorMessage] ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		paras.Add(Sql.CreateDbParameter("@DocumentId",DocumentId));
		paras.Add(Sql.CreateDbParameter("@RecordId",RecordId));
		paras.Add(Sql.CreateDbParameter("@ErrorMessage",ErrorMessage,ParameterDirection.Output));
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			ErrorMessage = dr["ErrorMessage"]== DBNull.Value ? null : Convert.ToString(dr["ErrorMessage"]);
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_DeleteInputValueById(long? DocumentId, long? RecordId, ref string ErrorMessage)
	{
		DataSet ds;
		return sp_DeleteInputValueById(out ds, DocumentId, RecordId, ref ErrorMessage);
	}

	public static int sp_DeleteTemplateNodeByInputType(out DataSet ds, string DocumentType, string InputType)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_DeleteTemplateNodeByInputType @DocumentType,@InputType  ";
		sql+="SELECT @r as  r ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		paras.Add(Sql.CreateDbParameter("@DocumentType",DocumentType));
		paras.Add(Sql.CreateDbParameter("@InputType",InputType));
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_DeleteTemplateNodeByInputType(string DocumentType, string InputType)
	{
		DataSet ds;
		return sp_DeleteTemplateNodeByInputType(out ds, DocumentType, InputType);
	}

	public static int sp_DeleteValueRecordAndDecendantByInputType(out DataSet ds, long? DocumentId, string InputType, bool? SaveToHistory)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_DeleteValueRecordAndDecendantByInputType @DocumentId,@InputType,@SaveToHistory  ";
		sql+="SELECT @r as  r ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		paras.Add(Sql.CreateDbParameter("@DocumentId",DocumentId));
		paras.Add(Sql.CreateDbParameter("@InputType",InputType));
		paras.Add(Sql.CreateDbParameter("@SaveToHistory",SaveToHistory));
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_DeleteValueRecordAndDecendantByInputType(long? DocumentId, string InputType, bool? SaveToHistory)
	{
		DataSet ds;
		return sp_DeleteValueRecordAndDecendantByInputType(out ds, DocumentId, InputType, SaveToHistory);
	}

	public static int sp_GetDocumentListByUserName(out DataSet ds, string userName)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_GetDocumentListByUserName @userName  ";
		sql+="SELECT @r as  r ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		paras.Add(Sql.CreateDbParameter("@userName",userName));
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_GetDocumentListByUserName(string userName)
	{
		DataSet ds;
		return sp_GetDocumentListByUserName(out ds, userName);
	}

	public static int sp_LoginLog(out DataSet ds, string userName)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_LoginLog @userName  ";
		sql+="SELECT @r as  r ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		paras.Add(Sql.CreateDbParameter("@userName",userName));
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_LoginLog(string userName)
	{
		DataSet ds;
		return sp_LoginLog(out ds, userName);
	}

	public static int sp_RenameInputType(out DataSet ds, long? TemplateRecordId, string NewInputType)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_RenameInputType @TemplateRecordId,@NewInputType  ";
		sql+="SELECT @r as  r ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		paras.Add(Sql.CreateDbParameter("@TemplateRecordId",TemplateRecordId));
		paras.Add(Sql.CreateDbParameter("@NewInputType",NewInputType));
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_RenameInputType(long? TemplateRecordId, string NewInputType)
	{
		DataSet ds;
		return sp_RenameInputType(out ds, TemplateRecordId, NewInputType);
	}

	public static int sp_SaveInputValue(out DataSet ds, long? UserId, long? DocumentId, long? DocumentInputItemId, string InputType, string TargetFieldName, string Value, ref long? NewDocumentInputItemId)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_SaveInputValue @UserId,@DocumentId,@DocumentInputItemId,@InputType,@TargetFieldName,@Value,@NewDocumentInputItemId OUTPUT  ";
		sql+="SELECT @r as  r, @NewDocumentInputItemId as [NewDocumentInputItemId] ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		paras.Add(Sql.CreateDbParameter("@UserId",UserId));
		paras.Add(Sql.CreateDbParameter("@DocumentId",DocumentId));
		paras.Add(Sql.CreateDbParameter("@DocumentInputItemId",DocumentInputItemId));
		paras.Add(Sql.CreateDbParameter("@InputType",InputType));
		paras.Add(Sql.CreateDbParameter("@TargetFieldName",TargetFieldName));
		paras.Add(Sql.CreateDbParameter("@Value",Value));
		paras.Add(Sql.CreateDbParameter("@NewDocumentInputItemId",NewDocumentInputItemId,ParameterDirection.Output));
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			NewDocumentInputItemId = dr["NewDocumentInputItemId"]== DBNull.Value ? null : (long?)Convert.ToInt64(dr["NewDocumentInputItemId"]);
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_SaveInputValue(long? UserId, long? DocumentId, long? DocumentInputItemId, string InputType, string TargetFieldName, string Value, ref long? NewDocumentInputItemId)
	{
		DataSet ds;
		return sp_SaveInputValue(out ds, UserId, DocumentId, DocumentInputItemId, InputType, TargetFieldName, Value, ref NewDocumentInputItemId);
	}

	public static int sp_SwapChildParent(out DataSet ds, long? DocumentId, long? ChildJishuWentiId, long? ParentJishuWentiId, ref string ErrorMsg)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_SwapChildParent @DocumentId,@ChildJishuWentiId,@ParentJishuWentiId,@ErrorMsg OUTPUT  ";
		sql+="SELECT @r as  r, @ErrorMsg as [ErrorMsg] ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		paras.Add(Sql.CreateDbParameter("@DocumentId",DocumentId));
		paras.Add(Sql.CreateDbParameter("@ChildJishuWentiId",ChildJishuWentiId));
		paras.Add(Sql.CreateDbParameter("@ParentJishuWentiId",ParentJishuWentiId));
		paras.Add(Sql.CreateDbParameter("@ErrorMsg",ErrorMsg,ParameterDirection.Output));
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			ErrorMsg = dr["ErrorMsg"]== DBNull.Value ? null : Convert.ToString(dr["ErrorMsg"]);
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_SwapChildParent(long? DocumentId, long? ChildJishuWentiId, long? ParentJishuWentiId, ref string ErrorMsg)
	{
		DataSet ds;
		return sp_SwapChildParent(out ds, DocumentId, ChildJishuWentiId, ParentJishuWentiId, ref ErrorMsg);
	}

	public static int sp_SyncVideoToTestSite(out DataSet ds)
	{
		int result = -1;

		string sql = "DECLARE @r int ";
		sql+="EXEC @r=sp_SyncVideoToTestSite   ";
		sql+="SELECT @r as  r ";
		List<System.Data.Common.DbParameter> paras = new List<System.Data.Common.DbParameter>();
		
		ds = Sql.SelectDataSet(sql, paras.ToArray());
		if(ds!=null && ds.Tables.Count>0)
		{
			DataRow dr = ds.Tables[ds.Tables.Count - 1].Rows[0];
			result = (int)dr["r"];
			ds.Tables.RemoveAt(ds.Tables.Count - 1);
			ds.AcceptChanges();
		}

		return result;
	}

	public static int sp_SyncVideoToTestSite()
	{
		DataSet ds;
		return sp_SyncVideoToTestSite(out ds);
	}

}
public class Functions
{
}
}
