﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CKZL.DAL
{
    public static class Config
    {
        private static Appsettings _appSettings = null;

        static Config()
        {
            try
            {
                string dir = System.AppDomain.CurrentDomain.BaseDirectory;
                string filePath = System.IO.Path.Combine(dir, "appsettings.json");
                string configText = System.IO.File.ReadAllText(filePath);
                _appSettings = JsonSerializer.Deserialize<Appsettings>(configText);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + ex.StackTrace);
            }
        }

        public static string DefaultConnectionString
        {
            get
            {

                return _appSettings.ConnectionStrings.DefaultConnection;
            }
        }

        public static string[] GetPatentStoreDBs()
        {
            return _appSettings.System.PatentStoreDBs;
        }

        public static string DriverClass
        {
            get
            {

                return _appSettings.System.DriverClass;
            }
        }
    }

    public class Appsettings
    {
        public ConnectionStrings ConnectionStrings { get; set; }

        public DALSystemConfig System { get; set; }
    }

    public class ConnectionStrings
    {
        public string DefaultConnection { get; set; }
    }
    public class DALSystemConfig
    {
        public string DriverClass { get; set; }
        public string CurrentPatentStoreConnectionString { get; set; }
        public string[] PatentStoreDBs { get; set; }
    }
}




