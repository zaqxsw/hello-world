﻿using System;
using System.Data;
using System.Text;
using System.Data.Common;
using System.Collections.Generic;

namespace CKZL.DAL
{
    public abstract class View<T>
    {
        /// <summary>
        /// 查询视图对象
        /// </summary>
        /// <param name="columns">查询字段,逗号间隔</param>
        /// <param name="condition">查询条件(格式字段=?),例:b=? and c = ? and d =?</param>
        /// <param name="order">排序</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns>视图对象</returns>
        public static T[] Select(string columns, string condition, string order, params DbParameter[] parameters)
        {
            if (!string.IsNullOrEmpty(columns))
            {
                StringBuilder sql = new StringBuilder();
                sql.Append("select ").Append(columns).Append(" from ").Append(typeof(T).Name);
                if (!string.IsNullOrEmpty(condition))
                {
                    sql.Append(" where ").Append(condition);
                }
                if (!string.IsNullOrEmpty(order))
                {
                    sql.Append(" order by ").Append(order);
                }

                return Sql.Select<T>(sql.ToString(), parameters);
            }

            return null;
        }

        public static DataTable SelectDataTable(string columns, string condition, string order, params DbParameter[] parameters)
        {
            StringBuilder sb = new StringBuilder();
            if (string.IsNullOrEmpty(columns))
            {
                columns = "*";
            }
            sb.Append("select ").Append(columns).Append(" from ").Append(typeof(T).Name);

            if (condition.Trim().Length > 0)
            {
                sb.Append(" where ").Append(condition);
            }

            if (order.Trim().Length > 0)
            {
                sb.Append(" order by ").Append(order);
            }

            return Sql.SelectDataTable(sb.ToString(), parameters);
        }

        public static int GetCount(string condition, params DbParameter[] parameters)
        {
            StringBuilder sql = new StringBuilder();
            sql.Append("select count(*) from ").Append(typeof(T).Name);
            if (!string.IsNullOrEmpty(condition))
            {
                sql.Append(" where ").Append(condition);
            }
            return int.Parse(Sql.ExecuteScalar(sql.ToString(), parameters).ToString());
        }
    }
}
