﻿using System;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using log4net;

namespace CKZL.DAL
{
    public sealed class Log
    {
        private static string moduleName;

        private static log4net.ILog _logger;
        static Log() 
        {
            _logger = log4net.LogManager.GetLogger("DBLoger");
            _logger.Info("test DBLoger");


            moduleName = typeof(Log).Module.Name;
        }

        public Log()
        {
            
        }

        public void Write(LogType logType, string message)
        {
            if (logType == LogType.Info) 
            {
                _logger.Info(message);
            }
            if (logType == LogType.Debug)
            {
                _logger.Debug(message);
            }
            if (logType == LogType.Warn)
            {
                _logger.Warn(message);
            }
            if (logType == LogType.Error)
            {
                _logger.Error(message);
            }
        }

        public static void Error(string message, Exception ex)
        {
            _logger.Error( message, ex);
        }

        public static void Error(string message)
        {
            _logger.Error(message);
        }

        public static void Debug(string message)
        {
            _logger.Debug(message);
        }

        public static void Info(string message)
        {
            _logger.Info(message);
        }

        public static void Warn(string message)
        {
            _logger.Warn(message);

        }
        
        public enum LogType
        {
            Error,
            Debug,
            Info,
            Warn
        }
    }
}