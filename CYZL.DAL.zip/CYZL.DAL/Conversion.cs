﻿using System;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Collections;
using System.Collections.Generic;

namespace CKZL.DAL
{
    public class Conversion
    {

        public static ArrayList DataRowToList(DataRow[] dr)
        {
            ArrayList al = new ArrayList();

            foreach (DataRow row in dr)
            {
                al.Add(DataRowToDictionary(row));
            }

            return al;
        }

        public static Dictionary<string, object> DataRowToDictionary(DataRow dr)
        {
            if (dr == null)
            {
                return null;
            }
            Dictionary<string, object> drow = new Dictionary<string, object>();
            foreach (DataColumn col in dr.Table.Columns)
            {
                if (col.DataType == typeof(DateTime) && !string.IsNullOrEmpty(dr[col.ColumnName].ToString()))
                {
                    drow.Add(col.ColumnName, ((DateTime)dr[col.ColumnName]).ToString("yyyy-MM-dd HH:mm:ss"));
                }
                else
                {
                    drow.Add(col.ColumnName, dr[col.ColumnName]);
                }
            }
            return drow;
        }

        public static ArrayList DataTableToList(DataTable dt)
        {
            if (dt == null)
            {
                return null;
            }
            return DataRowToList(dt.Select());
        }

        public static Dictionary<string, ArrayList> DataSetToDictionary(DataSet ds)
        {
            Dictionary<string, ArrayList> ret = new Dictionary<string, ArrayList>();

            if (ds != null)
            {
                foreach (DataTable dt in ds.Tables)
                {
                    ret[dt.TableName] = DataTableToList(dt);
                }
            }

            return ret;
        }

        


        

        public static int Asc(char character)
        {
            try
            {
                return (int)character;
            }
            catch
            {
                return -1;
            }
        }

        public static char Chr(int p)
        {
            return (char)p;
        }

        public static int StrToInt(string s, int d)
        {
            try
            {
                return int.Parse(s);
            }
            catch
            {
                return d;
            }
        }

        public static double StrToDouble(string s, double d)
        {
            try
            {
                return double.Parse(s);
            }
            catch
            {
                return d;
            }
        }

        public static long StrToLong(string s, long d)
        {
            try
            {
                return long.Parse(s);
            }
            catch
            {
                return d;
            }
        }

        public static DateTime StrToDateTime(string s, DateTime d)
        {
            try
            {
                return DateTime.Parse(s);
            }
            catch
            {
                return d;
            }
        }

        public static bool StrToBool(string s, bool d)
        {
            try
            {
                return bool.Parse(s);
            }
            catch
            {
                return d;
            }
        }

        public static short StrToShort(string s, short d)
        {
            try
            {
                return short.Parse(s);
            }
            catch
            {
                return d;
            }
        }

        public static decimal StrToDecimal(string s, decimal d)
        {
            try
            {
                return decimal.Parse(s);
            }
            catch
            {
                return d;
            }
        }

        public static string ToDBC(string input)
        {
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 12288)
                {
                    c[i] = (char)32;
                    continue;
                }
                if (c[i] > 65280 && c[i] < 65375)
                    c[i] = (char)(c[i] - 65248);
            }
            return new string(c);
        }
    }
}
