﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Text;
using System.Reflection;

namespace CKZL.DAL
{
    public abstract class Table<T>
    {
        /// <summary>
        /// 表名
        /// </summary>
        public string tableName;
        /// <summary>
        /// 更改过的字段集(通过"="显式赋值的字段)
        /// </summary>
        public Dictionary<string, object> EditFields = new Dictionary<string, object>();

        static Log log = new Log();


        /// <summary>
        /// 查询表对象
        /// </summary>
        /// <param name="columns">查询字段,逗号间隔</param>
        /// <param name="condition">查询条件(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns>表对象</returns>
        public static T SelectSingle(string columns, string condition,  params DbParameter[] parameters)
        {
           
            StringBuilder sql = new StringBuilder();
            sql.Append("select ").Append(columns).Append(" from ").Append(typeof(T).Name);
            if (!string.IsNullOrEmpty(condition))
            {
                sql.Append(" where ").Append(condition);
            }

            return Sql.SelectSingle<T>(sql.ToString(), parameters);
        }

        /// <summary>
        /// 查询表对象
        /// </summary>
        /// <param name="columns">查询字段,逗号间隔</param>
        /// <returns>表对象,防Sql注入</returns>
        public static T[] SelectAll(string columns)
        {
            return SelectAll(columns, "");
        }

        /// <summary>
        /// 查询表对象
        /// </summary>
        /// <param name="columns">查询字段,逗号间隔</param>
        /// <param name="order">排序</param>
        /// <returns>表对象,防Sql注入</returns>
        public static T[] SelectAll(string columns, string order)
        {
            StringBuilder sql = new StringBuilder();
            sql.Append("select ").Append(string.IsNullOrEmpty(columns) ? "*" : columns).Append(" from ").Append(typeof(T).Name);//.Append(" where ");

            if (!string.IsNullOrEmpty(order))
            {
                sql.Append(" order by ").Append(order);
            }

            return Sql.Select<T>(sql.ToString(), new DbParameter[0]);
        }

        /// <summary>
        /// 查询表对象
        /// </summary>
        /// <param name="columns">查询字段,逗号间隔</param>
        /// <param name="condition">查询条件(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="order">排序</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns>表对象</returns>
        public static T[] Select(string columns, string condition)
        {
            return Select( columns,  condition, "");
        }

        /// <summary>
        /// 查询表对象
        /// </summary>
        /// <param name="columns">查询字段,逗号间隔</param>
        /// <param name="condition">查询条件(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="order">排序</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns>表对象</returns>
        public static T[] Select(string columns, string condition, string order, params DbParameter[] parameters)
        {
            if (!string.IsNullOrEmpty(columns))
            {
                StringBuilder sql = new StringBuilder();
                sql.Append("select ").Append(columns).Append(" from ").Append(typeof(T).Name);
                if (!string.IsNullOrEmpty(condition))
                {
                    sql.Append(" where ").Append(condition);
                }
                if (!string.IsNullOrEmpty(order))
                {
                    sql.Append(" order by ").Append(order);
                }

                return Sql.Select<T>(sql.ToString(), parameters);
            }

            return null;
        }


        /// <summary>
        /// 查询表对象
        /// </summary>
        /// <param name="columns">查询字段</param>
        /// <param name="order">排序</param>
        /// <returns>表对象,防Sql注入</returns>
        public static T[] Select(Table<T> table, string columns, string order)
        {
            StringBuilder sql = new StringBuilder();
            sql.Append("select ").Append(string.IsNullOrEmpty(columns) ? "*" : columns).Append(" from ").Append(table.tableName);

            if (!string.IsNullOrEmpty(order))
            {
                sql.Append(" order by ").Append(order);
            }

            return Sql.Select<T>(sql.ToString(), new DbParameter[0]);
        }

        /// <summary>
        /// 获取符合条件的记录数
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public static int GetCount(string condition, params DbParameter[] parameters)
        {
            StringBuilder sql = new StringBuilder();
            sql.Append("select count(*) from ").Append(typeof(T).Name);
            if (!string.IsNullOrEmpty(condition))
            {
                sql.Append(" where ").Append(condition);
            }
            return int.Parse(Sql.ExecuteScalar(sql.ToString(), parameters).ToString());
        }


        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="columns">查询字段,逗号间隔</param>
        /// <param name="condition">查询条件(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="order">排序</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns></returns>
        public static DataTable SelectDataTable(string columns, string condition, string order, params DbParameter[] parameters)
        {
            StringBuilder sb = new StringBuilder();
            if (string.IsNullOrEmpty(columns))
            {
                columns = "*";
            }
            sb.Append("select ").Append(columns).Append(" from ").Append(typeof(T).Name);

            if (condition.Trim().Length > 0)
            {
                sb.Append(" where ").Append(condition);
            }

            if (!string.IsNullOrEmpty(order))
            {
                sb.Append(" order by ").Append(order);
            }

            return Sql.SelectDataTable(sb.ToString(), parameters);
        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="columns">查询字段,逗号间隔</param>
        /// <param name="condition">查询条件(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="order">排序</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns></returns>
        public static DataSet SelectDataSet(string columns, string condition, string order, params DbParameter[] parameters)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("select ").Append(columns).Append(" from ").Append(typeof(T).Name);

            if (condition.Trim().Length > 0)
            {
                sb.Append(" where ").Append(condition);
            }

            if (order.Trim().Length > 0)
            {
                sb.Append(" order by ").Append(order);
            }

            return Sql.SelectDataSet(sb.ToString(), parameters);
        }

        /// <summary>
        /// 添加记录
        /// </summary>
        /// <returns>受影响的行数</returns>
        public int Insert()
        {
            if (EditFields.Count == 0)
            {
                return -1;
            }

            StringBuilder sb = new StringBuilder();
            List<DbParameter> parameters = new List<DbParameter>();
            sb.Append("insert into ").Append(tableName).Append(" (");
            foreach (KeyValuePair<string, object> column in this.EditFields)
            {
                sb.Append(column.Key).Append(",");
                parameters.Add(Sql.CreateDbParameter("@" + column.Key, column.Value == null ? DBNull.Value : column.Value));
            }
            sb.Remove(sb.Length - 1, 1);
            sb.Append(") values (");
            foreach (KeyValuePair<string, object> column in this.EditFields)
            {
                sb.Append("@"+column.Key+",");
            }
            sb.Remove(sb.Length - 1, 1);
            sb.Append(")");

            EditFields.Clear();

            return Sql.ExecuteNonQuery(sb.ToString(), parameters.ToArray());
        }

        /// <summary>
        /// 添加记录,并返回自增ID(仅支持有自增ID的表)
        /// </summary>
        /// <returns>返回自增ID(仅支持有自增ID的表)</returns>
        public int InsertAndReturnIdentityId()
        {
            if (EditFields.Count == 0)
            {
                return -1;
            }

            StringBuilder sb = new StringBuilder();
            List<DbParameter> parameters = new List<DbParameter>();
            sb.Append("insert into ").Append(tableName).Append(" (");
            foreach (KeyValuePair<string, object> column in this.EditFields)
            {
                sb.Append(column.Key).Append(",");
                parameters.Add(Sql.CreateDbParameter("@" + column.Key, column.Value == null ? DBNull.Value : column.Value));
            }
            sb.Remove(sb.Length - 1, 1);
            sb.Append(")values(");
            foreach (KeyValuePair<string, object> column in this.EditFields)
            {
                sb.Append("@" + column.Key+",");
            }
            sb.Remove(sb.Length - 1, 1);
            sb.Append(")\n select SCOPE_IDENTITY()");

            EditFields.Clear();

            object id = Sql.ExecuteScalar(sb.ToString(), parameters.ToArray());
            if (id == null)
            {
                return -1;
            }
            else
            {
                return Conversion.StrToInt(id.ToString(), -1);
            }
        }

        /// <summary>
        /// 批量添加记录
        /// </summary>
        public static int Insert(Table<T>[] tables)
        {
            if (tables == null || tables.Length == 0)
            {
                return -1;
            }
            else
            {
                StringBuilder sql = new StringBuilder();
                sql.Append("insert into ").Append(tables[0].tableName).Append(" (");

                foreach (KeyValuePair<string, object> column in tables[0].EditFields)
                {
                    sql.Append(column.Key).Append(",");
                }
                sql.Remove(sql.Length - 1, 1);
                sql.Append(") values ");

                foreach (Table<T> table in tables)
                {
                    sql.Append("(");
                    foreach (KeyValuePair<string, object> column in table.EditFields)
                    {
                        if (column.Value == null)
                        {
                            sql.Append("NULL,");
                        }
                        else if (column.Value.GetType() == typeof(string))
                        {
                            sql.Append("'").Append(FilteSqlInfusion(column.Value.ToString())).Append("',");
                        }
                        else if (column.Value.GetType() == typeof(DateTime))
                        {
                            sql.Append("'").Append(((DateTime)column.Value).ToString("yyyy-MM-dd HH:mm:ss.fff")) .Append("',");
                        }
                        else
                        {
                            sql.Append("'").Append(column.Value.ToString()).Append("',");
                        }
                    }
                    sql.Remove(sql.Length - 1, 1);
                    sql.Append("),");
                }
                sql.Remove(sql.Length - 1, 1);

                return Sql.ExecuteNonQuery(sql.ToString());
            }
        }

        /// <summary>
        /// 添加一条记录
        /// 只有通过"="显式赋值的字段才会更新到数据库
        /// </summary>
        public static int Add(Table<T> model)
        {
            if (model == null )
            {
                return -1;
            }
            else
            {
                StringBuilder sql = new StringBuilder();

                List<DbParameter> parameters = new List<DbParameter>();

                sql.Append("insert into ").Append(model.tableName).Append(" (");

                foreach (KeyValuePair<string, object> column in model.EditFields)
                {
                    sql.Append("[").Append(column.Key).Append("]").Append(",");
                    parameters.Add(Sql.CreateDbParameter("@" + column.Key, column.Value == null ? DBNull.Value : column.Value));
                }
                sql.Remove(sql.Length - 1, 1);
                sql.Append(") values ");

                sql.Append("(");
                foreach (KeyValuePair<string, object> column in model.EditFields)
                {
                    sql.Append("@").Append(column.Key).Append(",");
                }
                sql.Remove(sql.Length - 1, 1);
                sql.Append(")");

                return Sql.ExecuteNonQuery(sql.ToString(), parameters.ToArray());
            }
        }

        /// <summary>
        /// 更新记录
        /// </summary>
        /// <param name="condition">条件(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns>受影响的行数</returns>
        public int Update(string condition, params DbParameter[] parameters)
        {
            if (EditFields.Count == 0)
            {
                return 0;
            }

            List<DbParameter> paras = new List<DbParameter>();
            StringBuilder sb = new StringBuilder();
            sb.Append("update ").Append(tableName).Append(" set ");
            foreach (KeyValuePair<string, object> column in this.EditFields)
            {
                sb.Append(column.Key).Append(" = @" + column.Key+",");
                paras.Add(Sql.CreateDbParameter("@" + column.Key,  column.Value == null ? DBNull.Value : column.Value ));
            }
            if (sb.ToString().EndsWith(","))
            {
                sb.Remove(sb.Length - 1, 1);
            }

            if (condition.Trim().Length > 0)
            {
                sb.Append(" where ").Append(condition);
            }

            foreach (DbParameter o in parameters)
            {
                paras.Add(o);
            }

            Clear();

            return Sql.ExecuteNonQuery(sb.ToString(), paras.ToArray());
        }

        /// <summary>
        /// 批量更新记录 Dictionary<条件,表> 
        /// </summary>
        public static int Update(Dictionary<string, Table<T>> tables)
        {
            DateTime sTime = DateTime.Now;
            int result = -1;
            StringBuilder sql = new StringBuilder();
            List<DbParameter> paras = new List<DbParameter>();
            foreach (KeyValuePair<string, Table<T>> table in tables)
            {
                if (table.Value.EditFields.Count > 0)
                {
                    sql.Append("\nupdate ").Append(table.Value.tableName).Append(" set ");
                    foreach (KeyValuePair<string, object> column in table.Value.EditFields)
                    {
                        sql.Append(column.Key).Append("=@p").Append(paras.Count.ToString()).Append(",");
                        paras.Add(Sql.CreateDbParameter("@p" + paras.Count.ToString(), column.Value));
                    }
                    sql.Remove(sql.Length - 1, 1);
                    sql.Append(" where ").Append(table.Key);
                }
            }

            if (sql.Length > 0)
            {

                DbConnection conn = null;
                DbTransaction trans = null;
                try
                {
                    conn = Sql.GetConnection();
                    trans = conn.BeginTransaction();
                    DbCommand cmd = Sql.CreateCommand(sql.ToString(), conn);
                    cmd.Transaction = trans;
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddRange(paras.ToArray());
                    result = cmd.ExecuteNonQuery();
                    trans.Commit();
                }
                catch (Exception e)
                {
                    if (trans != null)
                    {
                        trans.Rollback();
                    }

                    log.Write(Log.LogType.Error, e.Message + "(" + sql.ToString() + ")");
                }
                finally
                {
                    Sql.Close(conn);
                }
            }

            double useTime = DateTime.Now.Subtract(sTime).TotalMilliseconds;
            string logStr = "Table.UpdateBatch(" + sql.ToString() + ") 执行时间 " + useTime.ToString("F0") + " 毫秒";
            if (useTime / 1000 > 5)
            {
                log.Write(Log.LogType.Warn, logStr);
            }
#if DEBUG
            log.Write(Log.LogType.Debug, logStr);
#endif

            return result;
        }

        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="condition">条件(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns>受影响的行数</returns>
        public static int Delete(string condition, params DbParameter[] parameters)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("delete from ").Append(typeof(T).Name);

            if (condition.Trim().Length > 0)
            {
                sb.Append(" where ").Append(condition);
            }

            return Sql.ExecuteNonQuery(sb.ToString(), parameters);
        }

        /// <summary>
        /// 设置表字段更改副本
        /// </summary>
        protected void SetEditField(string name, object value)
        {
            this.EditFields[name] = value;
        }

        /// <summary>
        /// 清空表字段更改副本
        /// </summary>
        public void Clear()
        {
            this.EditFields.Clear();
        }

        /// <summary>
        /// 建立分页HTML代码
        /// </summary>
        /// <param name="curPageIndex">当前页</param>
        /// <param name="totalRecordCount">总记录数</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <returns></returns>
        public static string CreatePagerHtml(int curPageIndex, int totalRecordCount, int pageSize)
        {
            if (curPageIndex < 1)
                curPageIndex = 1;

            int pageCount = totalRecordCount % pageSize == 0 ? totalRecordCount / pageSize : totalRecordCount / pageSize + 1;

            //10页为一组，当前的组索引(从1开始)
            int curPageSetIndex = curPageIndex % 10 == 0 ? curPageIndex / 10 : curPageIndex / 10 + 1;

            int showStartIndex = (curPageSetIndex-1) * 10 + 1;//从整十开始显示：11，12，13 ...19,20 十页
            int showEndIndex = showStartIndex + 9;
            if (showEndIndex - pageCount > 0)
            {
                //不足10页，显示最后10页
                showStartIndex =pageCount - 9;
                showEndIndex = pageCount;
                if (showStartIndex < 1)
                    showStartIndex = 1;
            }
            

            StringBuilder sb = new StringBuilder(500);
            sb.Append("<table style='width:100%;' cellspacing='3' class='pager' >");
            sb.Append("<tr>");

            sb.Append("<td class='' width='auto'>第" + curPageIndex + "页/" + pageCount + "页&nbsp;&nbsp;&nbsp;共" + totalRecordCount + "条记录");
            sb.Append(" <input id=\"hdPageIndex\" name=\"pageIndex\" type=\"hidden\" value=\"" + curPageIndex + "\" />");
            sb.Append(" <input id=\"hdPageIndex\" name=\"totalRecordCount\" type=\"hidden\" value=\"" + totalRecordCount + "\" />");
            sb.Append(" <input id=\"pagerSubmit\" type=\"submit\" value=\"submit\" style=\"display:none;\" />");
            sb.Append("</td>");
            sb.Append(string.Format("<td class='first' title='去到第1页' {0} >｜&lt;</td>",curPageIndex>1 ? "onclick=\"pager_click(1)\"":""));
            sb.Append("<td class='pre' title='上10页'  onclick=\"pager_click(" + (showStartIndex - 10) + ")\">&lt;&lt;</td>");
            for (int i = showStartIndex; i <= showEndIndex && i <= pageCount; i++)
            {
                if (i == curPageIndex)
                {
                    sb.Append("<td class='cur'>");
                }
                else
                {
                    sb.Append("<td class='page'  onclick=\"pager_click(" + i + ")\" >");
                }
                sb.Append(i);
                sb.Append("</td>");
            }

            sb.Append("<td class='next' title='下10页'  onclick=\"pager_click(" + (showStartIndex + 10) + ")\" >&gt;&gt;</td>");
            sb.Append(string.Format("<td class='last' title='去到最后1页' {0} >&gt;｜</td>", curPageIndex < pageCount ? "onclick=\"pager_click(" + pageCount + ")\"":""));
            sb.Append("<td class='input'><input id=\"tbPageIndex\" type=\"text\"  size=\"2\"  title='跳到指定页' /></td>");
            sb.Append("<td class='go' title='跳到指定页' onclick=\"pager_click()\">GO</td>");
            sb.Append("</tr>");
            sb.Append("</table>");
            
            return sb.ToString();
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="columns">查询字段,逗号间隔</param>
        /// <param name="condition">查询条件(格式字段=@参数),例:b=@b and c =@c and d =@d</param>
        /// <param name="order">排序</param>
        /// <param name="pageIndex">当前页(从1开始)</param>
        /// <param name="pageSize">每页记录条数</param>
        /// <param name="parameters">参数值,建议采用parameters参数,parameters防Sql注入</param>
        /// <returns></returns>
        public static DataTable SelectByPage(string columns, string condition, string order,int pageIndex,int pageSize, params DbParameter[] parameters)
        {
            if (pageIndex < 1)
            {
                pageIndex = 1;
            }

            if (pageSize < 1)
            {
                pageSize = 20;
            }


            string sql = "";

            if (pageIndex == 1)//首页
            {
                sql = @"SELECT top {0} {1}
	                            , ROW_NUMBER() OVER(ORDER BY {2} ) AS RowIndex
	                            FROM {3}  {4} ";
                string where = "";
                if (!string.IsNullOrEmpty(condition))
                {
                    where = " where " + condition;
                }

                sql = string.Format(sql, pageSize,columns, order, typeof(T).Name, where);
            }
            else
            {

                int startIndex =( pageIndex-1) * pageSize + 1;
                int endIndex = startIndex + pageSize - 1;
                sql = @"SELECT * FROM 
                        (
                            SELECT {0}
	                            , ROW_NUMBER() OVER(ORDER BY {1} ) AS RowIndex
	                            FROM {2}  {3}  
                        )AS D
                        WHERE RowIndex BETWEEN {4}  AND {5}  ORDER by {1} ";
                string where = "";
                if (!string.IsNullOrEmpty(condition))
                {
                    where = " where " + condition;
                }

                sql = string.Format(sql, columns, order, typeof(T).Name, where, startIndex, endIndex);
            }

            return Sql.SelectDataTable(sql, parameters);
        }

        private static string FilteSqlInfusion(string input)
        {
            string sqlStr = "insert|delete|select|update|exec|varchar|drop|create|declare|truncate|cursor|begin|open|<--|-->|--|'";
            string[] sqlStrArr = sqlStr.Split('|');
            foreach (string strChild in sqlStrArr)
            {
                if (input.ToUpper().IndexOf(strChild.ToUpper()) != -1)
                {
                    return "";
                }
            }
            return input;
        }

        /*******************************扩展操作********************************/

        /// <summary>
        /// 更新某个字段的值为原值加(减)一个指定的增量
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="increment">增量</param>
        /// <param name="condition">SQL条件</param>
        /// <param name="parameters">参数</param>
        /// <returns></returns>
        public static int IncreaseFieldValue(string fieldName,int increment, string condition, params DbParameter[] parameters)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("update ").Append(typeof(T).Name);
            sb.Append(" set ").Append(fieldName);
            sb.Append(" =").Append(fieldName).Append("+").Append(increment.ToString());

            if (condition.Trim().Length > 0)
            {
                sb.Append(" where ").Append(condition);
            }

            return Sql.ExecuteNonQuery(sb.ToString(), parameters);
        }

    }
}
